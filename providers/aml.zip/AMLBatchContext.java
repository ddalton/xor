package com.sap.ariba.hana.aheap.base.aml;

import tools.xor.service.BatchContext;
import tools.xor.view.Query;

public class AMLBatchContext implements BatchContext
{

    private boolean shouldBatch;
    private Query query;

    public Query getQuery ()
    {
        return query;
    }

    public void setQuery (Query query)
    {
        this.query = query;
    }

    public boolean isShouldBatch ()
    {
        return shouldBatch;
    }

    public void setShouldBatch (boolean shouldBatch)
    {
        this.shouldBatch = shouldBatch;
    }
}
