/**
 * XOR, empowering Model Driven Architecture in J2EE applications
 *
 * Copyright (c) 2012, Dilip Dalton
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations 
 * under the License.
 */

package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseId;
import ariba.base.core.BaseObject;
import ariba.base.core.BaseVector;
import ariba.base.core.ClusterRoot;
import ariba.base.fields.Variant;
import ariba.base.fields.VariantRuntime;
import ariba.base.meta.server.ClassMetaDT;
import ariba.base.meta.server.MetaServer;
import ariba.base.server.BaseServer;
import ariba.util.core.SetUtil;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import tools.xor.EntityType;
import tools.xor.ExternalType;
import tools.xor.FilterType;
import tools.xor.ModelConstraint;
import tools.xor.MutableJsonProperty;
import tools.xor.MutableJsonTypeMapper;
import tools.xor.Property;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.TypeMapper;
import tools.xor.service.AbstractDataAccessService;
import tools.xor.service.DASFactory;
import tools.xor.service.PersistenceOrchestrator;
import tools.xor.service.Shape;
import tools.xor.util.PersistenceType;

import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class is part of the Data Access Service framework
 *
 * @author Dilip Dalton
 */
public class AMLDAS extends AbstractDataAccessService
{

    private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());

    private List<ModelConstraint> constraints;

    public AMLDAS (TypeMapper typeMapper, String name, DASFactory dasFactory)
    {
        super(dasFactory);
        this.typeMapper = typeMapper;

        registerConverters();

        // Register types that should be left as is and not be treated as an entity
        MutableJsonTypeMapper.addUnchanged(BaseId.class);
        MutableJsonTypeMapper.addUnchanged(ariba.util.core.Date.class);
        //MutableJsonTypeMapper.addUnchanged(BaseVector.class);
    }

    @Override
    public Shape getShape() {
        if(!shapes.get(DEFAULT_SHAPE).isBuildFinished()) {
            return shapes.get(DEFAULT_SHAPE);
        }

        // Needs to be always present to allow user overrides
        if(hasOverriddenShape()) {
            return getOverriddenShape();
        }

        if(Base.getSession() == null) {
            throw new IllegalStateException("getShape() needs to be invoked in a Session context");
        }
        Variant variant = Base.getSession().getVariant();

        if(variant == null || variant.isPlain()) {
            return super.getShape();
        } else {
            if(!shapes.containsKey(variant.getName())) {
                addShape(variant.getName());
            }

            return shapes.get(variant.getName());
        }
    }


    private void registerConverters ()
    {
        MutableJsonProperty.registerConverter(BaseId.class, getBaseIdConverter());

        MutableJsonProperty.Converter dateConverter = MutableJsonProperty.findConverter(java.util.Date.class);
        if (dateConverter != null) {
            MutableJsonProperty.registerConverter(ariba.util.core.Date.class, new AribaDateConverter(dateConverter));
        }

        MutableJsonProperty.registerConverter(BaseVector.class, getBaseVectorConverter());
    }

    public class AribaDateConverter extends MutableJsonProperty.AbstractConverter {

        private MutableJsonProperty.Converter dateConverter;

        public AribaDateConverter(MutableJsonProperty.Converter dateConverter) {
            this.dateConverter = dateConverter;
        }

        @Override public Object toDomain (Settings settings,
                                          JSONObject jsonObject,
                                          Property property,
                                          String key) throws
            JSONException
        {
            Date date = (Date)dateConverter.toDomain(settings, jsonObject, property, key);
            if (date != null) {
                return new ariba.util.core.Date(date.getTime());
            } else {
                return null;
            }
        }

        @Override public void add (Settings settings, JSONArray jsonArray, Object object)
        {
            this.dateConverter.add(settings, jsonArray, object);
        }
    }

    private MutableJsonProperty.Converter getBaseIdConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof BaseId)
                        return value;
                    else {
                        String bidString = jsonObject.getString(key).trim();
                        if(bidString != null && !"".equals(bidString)) {
                            return BaseId.parse(jsonObject.getString(key));
                        }
                    }
                }
                return null;
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(((BaseId)object).toDBString());
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, ((BaseId)object).toDBString());
            }
        };

        return c;
    }

    private MutableJsonProperty.Converter getBaseVectorConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof BaseVector)
                        return value;
                    else {
                        // BaseVector methods take in a List instance
                        return new ArrayList<>();
                    }
                }
                return null;
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(object);
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, new JSONArray());
            }
        };

        return c;
    }

    public void setConstraints(List<ModelConstraint> value) {
        this.constraints = value;
    }

    @Override
    public void addShape (String name)
    {
        Shape shape = getOrCreateShape(name);

        logger.info("Getting the list of AML mapped classes");
        for (ClassMetaDT classMapping : getEntities(shape)) {
            logger.debug("     Adding AML persisted class: " + classMapping.getName());
            defineTypes(classMapping, shape);
        }

        // Set the super type
        defineSuperType(shape);

        // Set the base types
        setBaseTypes(shape);

        // Define the properties for the Types
        // This will end up defining the simple types
        defineProperties(shape);

        postProcess(shape);
    }

    /**
     * Will include both ClusterRoot and BaseObject types
     * @param shape
     * @return
     */
    private Set<ClassMetaDT> getEntities (Shape shape)
    {
        Variant variant = Variant.Plain;
        if (!AbstractDataAccessService.DEFAULT_SHAPE.equals(shape.getName())) {
            VariantRuntime runtime = MetaServer.getMetaServer().
                getMetadataServerSupport().metadata().getVariantRuntime();
            variant = runtime.findVariant(shape.getName());
        }

        if (variant == null) {
            logger.error(
                "Unable to find variant with name: " + shape.getName()
                    + ", falling back to plain variant");
            variant = Variant.Plain;
        }

        BaseServer baseServer = BaseServer.baseServer();
        ClassMetaDT baseObjectClass = baseServer.metadata.metadata().findClass(
            BaseObject.ClassName, variant);
        ClassMetaDT[] allSubclasses = baseObjectClass.getSubTypes();

        Set<ClassMetaDT> result = new HashSet<ClassMetaDT>();
        result.add(baseObjectClass);

        for (ClassMetaDT classMapping : allSubclasses) {

            //if (!classMapping.isNoSchema && !classMapping.isAbstract) {
            // If the class is not tracked then it is treated as a simple type which is not good
            if (!classMapping.isNoSchema) {
                ClassMetaDT variantDT = baseServer.metadata.metadata().findClass(
                    classMapping.getType().getClassName(), variant);
                // Plain variant entities are already tracked as part of the default shape
                // But we make another copy as the Shape is responsible for all its Types

                // This is already captured as part of the default shape
                // So we can skip it
                if (shape.getShapeStrategy() == Shape.ShapeStrategy.SHARED) {
                    if (!variant.isPlain() && variantDT.getDeclaredVariant().isPlain()) {
                        continue;
                    }
                }

                // Check if this a dynamic class
                // Currently we skip these classes
                String className = classMapping.getType().getClassName();
                try {
                    Class clazz = Class.forName(className);
                    try {
                        if (clazz.getMethod("getTypeName").getDeclaringClass() == clazz) {
                            continue;
                        }
                    }
                    catch (NoSuchMethodException e) {
                        continue;
                    }
                }
                catch (ClassNotFoundException e) {
                    continue;
                }

                result.add(variantDT);
            }
        }

        return result;
    }

    private void populateFilter(Set<String> whitelist, Set<String> blacklist) {
        if(constraints != null) {
            for (ModelConstraint mc : constraints) {
                if (mc.getFilterType() == FilterType.BLACKLIST) {
                    blacklist.add(mc.getPath());
                }
                else {
                    whitelist.add(mc.getPath());
                }
            }
        }
    }

    private boolean isSupported(String typeName) {
        Set<String> whitelist = SetUtil.set();
        Set<String> blacklist = SetUtil.set();
        populateFilter(whitelist, blacklist);

        // If whitelist is present filter using it
        if(whitelist.size() > 0) {
            boolean isFound = false;
            for(String path: whitelist) {
                if(typeName.startsWith(path)) {
                    // include this type
                    return true;
                }
            }
        }

        // Check that this particular type is not blacklisted
        if(blacklist.size() > 0) {
            for(String path: blacklist) {
                if(typeName.startsWith(path)) {
                    return false;
                }
            }
        }

        return true;
    }

    protected void defineTypes (ClassMetaDT classMapping, Shape shape)
    {
        if(!isSupported(classMapping.getType().getClassName())) {
            return;
        }

        AMLType dataType = new AMLType(classMapping);
        logger.debug("Defined data type: " + dataType.getName());
        shape.addType(classMapping.getType().getClassName(), dataType);
    }

    @Override
    protected void defineSuperType (Shape shape){
        List<EntityType> entityTypes = new ArrayList<EntityType>();
        for(Type type: shape.getUniqueTypes()) {
            if(!EntityType.class.isAssignableFrom(type.getClass()))
                continue;

            EntityType extendedType = (EntityType) type;
            entityTypes.add(extendedType);
        }

        for(EntityType type: entityTypes) {

            AMLType amlType = (AMLType) type;
            Type superType = shape.getType(amlType.getSuperTypeClassName());
            if(superType != null && (superType instanceof EntityType)) {
                amlType.setSuperType((EntityType)superType);
            }

        }
    }

    protected void defineProperties (Shape shape)
    {
        System.out.println("********** No of types for shape: " + shape.getName() + " is: " + shape.getUniqueTypes().size() + " [If less than expected, then the runtime folder might be missing amls, such as extensions.]");

        for (Type type : shape.getUniqueTypes()) {
            if (!type.isOpen() && AMLType.class.isAssignableFrom(type.getClass())) {
                AMLType aMLType = (AMLType) type;
                aMLType.setProperty(shape);
            }
        }

        // AML does not support bi-directional relationships
    }

    // TODO: How is this different from setSuperType?
    // For now we use the supertype as the base type
    protected void setBaseTypes (Shape shape)
    {
        for (Type type : shape.getUniqueTypes()) {
            if (AMLType.class.isAssignableFrom(type.getClass())) {

                AMLType aMLType = (AMLType) type;

                if (aMLType.isEmbedded())
                    continue;

                List<Type> baseTypes = new ArrayList<Type>();
                if(aMLType.getSuperType() != null) {
                    baseTypes.add(aMLType.getSuperType());
                }
                aMLType.setBaseType(baseTypes);
            }
        }
    }

    @Override
    public PersistenceType getAccessType ()
    {
        return PersistenceType.AML;
    }

    @Override public PersistenceOrchestrator createPO (Object sessionContext, Object data)
    {
        return new AMLPersistenceOrchestrator();
    }

}
