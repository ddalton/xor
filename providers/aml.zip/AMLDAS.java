/**
 * XOR, empowering Model Driven Architecture in J2EE applications
 *
 * Copyright (c) 2012, Dilip Dalton
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations 
 * under the License.
 */

package com.sap.ariba.hana.aheap.baseschool.aml;

import ariba.base.core.BaseId;
import ariba.base.core.BaseVector;
import ariba.base.core.ClusterRoot;
import ariba.base.fields.Variant;
import ariba.base.meta.server.ClassMetaDT;
import ariba.base.server.BaseServer;
import ariba.util.core.SetUtil;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import tools.xor.EntityType;
import tools.xor.ExternalType;
import tools.xor.FilterType;
import tools.xor.ModelConstraint;
import tools.xor.MutableJsonProperty;
import tools.xor.MutableJsonTypeMapper;
import tools.xor.Property;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.TypeMapper;
import tools.xor.service.AbstractDataAccessService;
import tools.xor.service.DASFactory;
import tools.xor.service.PersistenceOrchestrator;
import tools.xor.util.PersistenceType;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class is part of the Data Access Service framework
 *
 * @author Dilip Dalton
 */
public class AMLDAS extends AbstractDataAccessService
{

    private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());

    private List<ModelConstraint> constraints;

    public AMLDAS (TypeMapper typeMapper, String name, DASFactory dasFactory)
    {
        super(dasFactory);
        this.typeMapper = typeMapper;

        registerConverters();

        // Register types that should be left as is and not be treated as an entity
        MutableJsonTypeMapper.addUnchanged(BaseId.class);
        MutableJsonTypeMapper.addUnchanged(ariba.util.core.Date.class);
        //MutableJsonTypeMapper.addUnchanged(BaseVector.class);
    }

    private void registerConverters ()
    {
        MutableJsonProperty.registerConverter(BaseId.class, getBaseIdConverter());

        MutableJsonProperty.Converter dateConverter = MutableJsonProperty.findConverter(java.util.Date.class);
        if (dateConverter != null) {
            MutableJsonProperty.registerConverter(ariba.util.core.Date.class, new AribaDateConverter(dateConverter));
        }

        MutableJsonProperty.registerConverter(BaseVector.class, getBaseVectorConverter());
    }

    public class AribaDateConverter extends MutableJsonProperty.AbstractConverter {

        private MutableJsonProperty.Converter dateConverter;

        public AribaDateConverter(MutableJsonProperty.Converter dateConverter) {
            this.dateConverter = dateConverter;
        }

        @Override public Object toDomain (Settings settings,
                                          JSONObject jsonObject,
                                          Property property,
                                          String key) throws
            JSONException
        {
            Date date = (Date)dateConverter.toDomain(settings, jsonObject, property, key);
            if (date != null) {
                return new ariba.util.core.Date(date.getTime());
            } else {
                return null;
            }
        }

        @Override public void add (Settings settings, JSONArray jsonArray, Object object)
        {
            this.dateConverter.add(settings, jsonArray, object);
        }
    }

    private MutableJsonProperty.Converter getBaseIdConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof BaseId)
                        return value;
                    else {
                        String bidString = jsonObject.getString(key).trim();
                        if(bidString != null && !"".equals(bidString)) {
                            return BaseId.parse(jsonObject.getString(key));
                        }
                    }
                }
                return null;
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(((BaseId)object).toDBString());
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, ((BaseId)object).toDBString());
            }
        };

        return c;
    }

    private MutableJsonProperty.Converter getBaseVectorConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof BaseVector)
                        return value;
                    else {
                        // BaseVector methods take in a List instance
                        return new ArrayList<>();
                    }
                }
                return null;
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(object);
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, new JSONArray());
            }
        };

        return c;
    }

    public void setConstraints(List<ModelConstraint> value) {
        this.constraints = value;
    }

    public void define ()
    {

        logger.info("Getting the list of AML mapped classes");
        for (ClassMetaDT classMapping : getEntities()) {
            logger.debug("     Adding AML persisted class: " + classMapping.getName());
            defineTypes(classMapping);
        }

        // Set the super type
        defineSuperType();

        // Set the base types
        setBaseTypes();

        // Define the properties for the Types
        // This will end up defining the simple types
        defineProperties();

        postProcess();
    }

    private Set<ClassMetaDT> getEntities ()
    {
        BaseServer baseServer = BaseServer.baseServer();
        ClassMetaDT clusterRootClass = baseServer.metadata.metadata().findClass(
            ClusterRoot.ClassName, Variant.Plain);
            ClassMetaDT[] allSubclasses = clusterRootClass.getSubTypes();

        Set<ClassMetaDT> result = new HashSet<ClassMetaDT>();
        for (ClassMetaDT classMapping : allSubclasses) {
            //if (!classMapping.isNoSchema && !classMapping.isAbstract) {
            // If the class is not tracked then it is treated as a simple type which is not good
            if (!classMapping.isNoSchema) {
                result.add(classMapping);
            }
        }

        return result;
    }

    private void populateFilter(Set<String> whitelist, Set<String> blacklist) {
        if(constraints != null) {
            for (ModelConstraint mc : constraints) {
                if (mc.getFilterType() == FilterType.BLACKLIST) {
                    blacklist.add(mc.getPath());
                }
                else {
                    whitelist.add(mc.getPath());
                }
            }
        }
    }

    private boolean isSupported(String typeName) {
        Set<String> whitelist = SetUtil.set();
        Set<String> blacklist = SetUtil.set();
        populateFilter(whitelist, blacklist);

        // If whitelist is present filter using it
        if(whitelist.size() > 0) {
            boolean isFound = false;
            for(String path: whitelist) {
                if(typeName.startsWith(path)) {
                    // include this type
                    return true;
                }
            }
        }

        // Check that this particular type is not blacklisted
        if(blacklist.size() > 0) {
            for(String path: blacklist) {
                if(typeName.startsWith(path)) {
                    return false;
                }
            }
        }

        return true;
    }

    protected void defineTypes (ClassMetaDT classMapping)
    {
        if(!isSupported(classMapping.getType().getClassName())) {
            return;
        }

        AMLType dataType = new AMLType(classMapping);
        logger.debug("Defined data type: " + dataType.getName());
        addType(classMapping.getType().getClassName(), dataType);

        for (Type type : dataType.getEmbeddableTypes()) {
            addType(type.getName(), type);
        }
    }

    @Override
    protected void defineSuperType (){
        List<EntityType> entityTypes = new ArrayList<EntityType>();
        for(Type type: new HashSet<Type>(types.values())) {
            if(!EntityType.class.isAssignableFrom(type.getClass()))
                continue;

            EntityType extendedType = (EntityType) type;
            entityTypes.add(extendedType);
        }

        for(EntityType type: entityTypes) {

            AMLType amlType = (AMLType) type;
            Type superType = getType(amlType.getSuperTypeClassName());
            if(superType != null) {
                amlType.setSuperType((EntityType)superType);
            }

        }
    }

    protected void defineProperties ()
    {
        for (Type type : types.values()) {
            if (!type.isOpen() && AMLType.class.isAssignableFrom(type.getClass())) {
                AMLType aMLType = (AMLType) type;
                aMLType.setProperty(this);
            }
        }

        // AML does not support bi-directional relationships
    }

    @Override
    protected void setBiDirectionOnDerivedType(ExternalType derivedType) {
        // BiDirectional relationship not supported/managed by AML
    }

    @Override
    protected void initOrder() {
        // TODO: Need to figure out how to sort a entity forest that has cycles
    }

    // TODO: How is this different from setSuperType?
    // For now we use the supertype as the base type
    protected void setBaseTypes ()
    {
        for (Type type : types.values()) {
            if (AMLType.class.isAssignableFrom(type.getClass())) {

                AMLType aMLType = (AMLType) type;

                if (aMLType.isEmbedded())
                    continue;

                List<Type> baseTypes = new ArrayList<Type>();
                if(aMLType.getSuperType() != null) {
                    baseTypes.add(aMLType.getSuperType());
                }
                aMLType.setBaseType(baseTypes);
            }
        }
    }

    @Override
    public List<String> getAggregateList ()
    {
        List<String> result = new ArrayList<String>();

        for (ClassMetaDT classMapping : getEntities()) {
            defineTypes(classMapping);
            result.add(classMapping.getName());
        }

        return result;
    }

    @Override
    public PersistenceType getAccessType ()
    {
        return PersistenceType.AML;
    }

    @Override public PersistenceOrchestrator createPO (Object sessionContext, Object data)
    {
        return new AMLPersistenceOrchestrator();
    }

}
