package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.ClusterRoot;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.providers.jdbc.JDBCDAS;
import tools.xor.service.AbstractEntityScroll;
import tools.xor.service.AggregateManager;
import tools.xor.service.DataAccessService;
import tools.xor.util.ApplicationConfiguration;
import tools.xor.util.Constants;
import tools.xor.view.Query;
import tools.xor.view.QueryBuilder;
import tools.xor.view.QueryView;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class AMLEntityScroll extends AbstractEntityScroll
{
    private static final String WHERE_CLAUSE = "WHERE ";

    Connection connection;
    String sqlString;
    Settings settings;
    Query query;

    public AMLEntityScroll(Settings settings, AggregateManager source, AggregateManager target) {
        // We are fine with the source being a JDBC AM
        DataAccessService das = source.getDAS();
        DataSource ds = ((JDBCDAS)das).getDataSource();
        try {
            this.connection = ds.getConnection();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        // We get the query string from the target
        this.settings = settings;
        Type referenceType = settings.getEntityType();
        try {
            QueryView aggregateView = settings.getView().getEntityView(
                referenceType,
                false);

            QueryBuilder qb = target.getDAS().getQueryBuilder();
            qb.init(
                referenceType,
                aggregateView,
                new ArrayList());
            this.query = qb.constructQuery(settings, new HashMap());
            qb.postProcess(aggregateView, settings, query, new HashMap<>());

            // Now convert the AMLQuery to SQL
            this.sqlString = ((AMLQuery)query).convertToSQL();

            // We will chop off the WHERE clause section since we don't want to filter
            // the contents as AQL automatically adds filtering to the generated SQL
            if(this.sqlString.indexOf(WHERE_CLAUSE) != -1) {
                this.sqlString = this.sqlString.substring(0, this.sqlString.indexOf(WHERE_CLAUSE));
            }

            // check if partition filtering is on
            applyPartitionFilter();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String applyPartitionFilter() {

        String partitionString = null;
        if (ApplicationConfiguration.config().containsKey(Constants.Config.MIGRATE_FILTER_PARTITION)) {
            partitionString = ApplicationConfiguration.config().getString(Constants.Config.MIGRATE_FILTER_PARTITION);
        }

        String partitionNumberName = ClusterRoot.KeyPartitionNumber;
        int partitionIndex = 0;
        for(; partitionIndex < this.query.getColumns().size(); partitionIndex++) {
            if(this.query.getColumns().get(partitionIndex).equals(partitionNumberName)) {
                break;
            }
        }

        // has partition number
        if(partitionIndex < this.query.getColumns().size()) {
            int startPos = this.sqlString.indexOf(" "); // first column in select clause
            if(partitionIndex > 0) {
                startPos = nthoccurrence(this.sqlString, ",", partitionIndex) + 1;
            }
            int endPos = this.sqlString.indexOf(WHERE_CLAUSE); // last column in select clause
            if(partitionIndex < this.query.getColumns().size()-1) {
                endPos = nthoccurrence(this.sqlString, ",", partitionIndex+1);
            }

            // extract the partitionnumber column name from the query
            String partitionNumberColumn = this.sqlString.substring(startPos, endPos);
            this.sqlString = this.sqlString + " WHERE " + partitionNumberColumn + " IN (" + partitionString + ")";
        }

        return this.sqlString;
    }

    public static int nthoccurrence(String str, String substr, int n) {

        if(n < 1) {
            throw new IllegalArgumentException("n has to be greater than 0");
        }

        int pos = str.indexOf(substr);
        while (--n > 0 && pos != -1)
            pos = str.indexOf(substr, pos + 1);
        return pos;
    }

    @Override public void close () throws IOException
    {
        // close the resources used by the abstract class
        super.close();

        try {
            if (this.connection != null)
                this.connection.close();
        }
        catch (Exception e) {}
        ;
    }

    @Override protected Settings getSettings ()
    {
        return settings;
    }

    @Override protected Connection getConnection ()
    {
        return connection;
    }

    @Override protected String getSQLString ()
    {
        return sqlString;
    }

    @Override protected Query getQuery ()
    {
        return query;
    }

}
