package com.sap.ariba.hana.aheap.base.aml;

import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.providers.jdbc.JDBCDAS;
import tools.xor.service.AbstractEntityScroll;
import tools.xor.service.AggregateManager;
import tools.xor.service.DataAccessService;
import tools.xor.view.Query;
import tools.xor.view.QueryBuilder;
import tools.xor.view.QueryView;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class AMLEntityScroll extends AbstractEntityScroll
{
    Connection connection;
    String sqlString;
    Settings settings;
    Query query;

    public AMLEntityScroll(Settings settings, AggregateManager source, AggregateManager target) {
        // We are fine with the source being a JDBC AM
        DataAccessService das = source.getDAS();
        DataSource ds = ((JDBCDAS)das).getDataSource();
        try {
            this.connection = ds.getConnection();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

        // We get the query string from the target
        Type referenceType = settings.getEntityType();
        try {
            QueryView aggregateView = settings.getView().getEntityView(
                referenceType,
                false);

            QueryBuilder qb = target.getDAS().getQueryBuilder();
            qb.init(
                referenceType,
                aggregateView,
                new ArrayList());
            this.query = qb.constructQuery(settings, new HashMap());
            qb.postProcess(aggregateView, settings, query, new HashMap<>());

            // Now convert the AMLQuery to SQL
            this.sqlString = ((AMLQuery)query).convertToSQL();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override public void close () throws IOException
    {
        // close the resources used by the abstract class
        super.close();

        try {
            if (this.connection != null)
                this.connection.close();
        }
        catch (Exception e) {}
        ;
    }

    @Override protected Settings getSettings ()
    {
        return settings;
    }

    @Override protected Connection getConnection ()
    {
        return connection;
    }

    @Override protected String getSQLString ()
    {
        return sqlString;
    }

    @Override protected Query getQuery ()
    {
        return query;
    }

}
