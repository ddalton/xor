package com.sap.ariba.hana.base.aml;

import ariba.base.core.BaseId;
import ariba.util.core.Date;
import tools.xor.BasicType;
import tools.xor.MutableJsonTypeMapper;
import tools.xor.util.ExcelJsonCreationStrategy;
import tools.xor.util.ObjectCreator;
import tools.xor.util.POJOCreationStrategy;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

/**
 * Created by i844711 on 1/6/17.
 */
public class AMLJsonCreationStrategy extends ExcelJsonCreationStrategy
{
    public AMLJsonCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    protected void setDomainCreationStrategy(ObjectCreator objectCreator) {
        pojoCS = new AMLPOJOCreationStrategy(objectCreator);
    }
}


