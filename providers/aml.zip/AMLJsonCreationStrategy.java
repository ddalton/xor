package com.sap.ariba.hana.aheap.base.aml;

import tools.xor.EntityType;
import tools.xor.util.ClassUtil;
import tools.xor.util.ExcelJsonCreationStrategy;
import tools.xor.util.ObjectCreator;

public class AMLJsonCreationStrategy extends ExcelJsonCreationStrategy
{
    public AMLJsonCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    protected void setDomainCreationStrategy(ObjectCreator objectCreator) {
        pojoCS = new AMLPOJOCreationStrategy(objectCreator);
    }

    @Override
    public Object patchInstance(EntityType entityType) {
        return pojoCS.patchInstance(entityType);
    }
}


