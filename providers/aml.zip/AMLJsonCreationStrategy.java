package com.sap.ariba.hana.base.aml;

import tools.xor.util.ExcelJsonCreationStrategy;
import tools.xor.util.ObjectCreator;

public class AMLJsonCreationStrategy extends ExcelJsonCreationStrategy
{
    public AMLJsonCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    protected void setDomainCreationStrategy(ObjectCreator objectCreator) {
        pojoCS = new AMLPOJOCreationStrategy(objectCreator);
    }
}


