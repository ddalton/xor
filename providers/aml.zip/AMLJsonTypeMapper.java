package com.sap.ariba.hana.base.aml;

import tools.xor.ExcelJsonTypeMapper;
import tools.xor.TypeMapper;
import tools.xor.util.CreationStrategy;
import tools.xor.util.ObjectCreator;

/**
 * Created by i844711 on 1/6/17.
 */
public class AMLJsonTypeMapper extends ExcelJsonTypeMapper
{
    @Override
    protected TypeMapper createInstance() {
        return new AMLJsonTypeMapper();
    }

    @Override
    public CreationStrategy getCreationStrategy(ObjectCreator oc) {
        return new AMLJsonCreationStrategy(oc);
    }
}
