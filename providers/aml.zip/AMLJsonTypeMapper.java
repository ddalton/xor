package com.sap.ariba.hana.aheap.base.aml;

import tools.xor.ExcelJsonTypeMapper;
import tools.xor.TypeMapper;
import tools.xor.util.CreationStrategy;
import tools.xor.util.ObjectCreator;

public class AMLJsonTypeMapper extends ExcelJsonTypeMapper
{
    @Override
    protected TypeMapper createInstance() {
        return new AMLJsonTypeMapper();
    }

    @Override
    public CreationStrategy getCreationStrategy(ObjectCreator oc) {
        return new AMLJsonCreationStrategy(oc);
    }

    @Override
    public boolean isDomain(Class<?> clazz) {
        if (clazz.getCanonicalName().startsWith("ariba")) {
            return true;
        }

        return super.isDomain(clazz);
    }
}
