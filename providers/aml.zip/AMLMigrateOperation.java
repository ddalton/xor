package com.sap.ariba.hana.aheap.base.aml;

import org.json.JSONObject;
import tools.xor.EntityType;
import tools.xor.Settings;
import tools.xor.operation.MigrateOperation;
import tools.xor.service.AggregateManager;
import tools.xor.service.EntityScroll;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class AMLMigrateOperation extends MigrateOperation
{
    public AMLMigrateOperation (AggregateManager source,
                                AggregateManager target, Integer queueSize)
    {
        super(source, target, queueSize);
    }

    public static class AMLConsumer extends Consumer {

        public AMLConsumer (BlockingQueue queue,
                            AggregateManager target, Settings settings)
        {
            super(queue, target, settings);
        }

        @Override
        protected void persistToDB(List<JSONObject> batch) {

            String realm = (String)getSettings().getSessionContext();
            AribaPlatformCode apc = new AribaPlatformCode((String) realm, true)
            {
                @Override public void doWork ()
                {
                    AMLConsumer.super.persistToDB(batch);
                }
            };
            apc.execute();
        }
    }

    public static class AMLProducer extends Producer {

        public AMLProducer (BlockingQueue queue,
                            AggregateManager source,
                            AggregateManager target, Settings settings)
        {
            super(queue, source, target, settings);
        }

        @Override
        protected EntityScroll<JSONObject> getEntityScroll() {
            String realm = (String)getSettings().getSessionContext();
            AribaPlatformCode apc = new AribaPlatformCode((String) realm, true)
            {
                @Override public void doWork ()
                {
                    setResult(AMLProducer.super.getEntityScroll());
                }
            };
            apc.execute();

            return (EntityScroll<JSONObject>)apc.getResult();
        }
    }

    @Override
    protected Producer createProducer(BlockingQueue queue, AggregateManager source, AggregateManager target, Settings settings) {
        return new AMLProducer(queue, source, target, settings);
    }

    @Override
    protected Consumer createConsumer(BlockingQueue queue, AggregateManager target, Settings settings) {
        return new AMLConsumer(queue, target, settings);
    }

    @Override
    public List<EntityType> getEntitiesInOrder(String[] entities, Settings settings) {
        String realm = (String)settings.getSessionContext();
        AribaPlatformCode apc = new AribaPlatformCode((String) realm, true)
        {
            @Override public void doWork ()
            {
                setResult(AMLMigrateOperation.super.getEntitiesInOrder(entities, settings));
            }
        };
        apc.execute();

        return (List<EntityType>)apc.getResult();
    }

    @Override
    public Settings build(EntityType entityType, Settings settings) {

        String realm = (String)settings.getSessionContext();
        AribaPlatformCode apc = new AribaPlatformCode((String) realm, true)
        {
            @Override public void doWork ()
            {
                setResult(AMLMigrateOperation.super.build(entityType, settings));
            }
        };
        apc.execute();

        return (Settings)apc.getResult();
    }
}
