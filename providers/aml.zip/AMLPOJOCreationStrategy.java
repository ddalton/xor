package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseObject;
import ariba.base.core.Partition;
import tools.xor.BasicType;
import tools.xor.BusinessObject;
import tools.xor.EntityType;
import tools.xor.Property;
import tools.xor.util.ClassUtil;
import tools.xor.util.ObjectCreator;
import tools.xor.util.POJOCreationStrategy;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

public class AMLPOJOCreationStrategy extends POJOCreationStrategy
{
    public AMLPOJOCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    public Object newInstance(Object from, BasicType type, Class<?> toClass, BusinessObject container,
                              Property containmentProperty) throws Exception {

        if(type != null && !BaseObject.class.isAssignableFrom(ClassUtil.getUnEnhanced(type.getInstanceClass())) && type.isDataType()) {
            // Handle simple types like String etc...
            return type.newInstance(from);
        }

        // If toClass is null then fallback to type
        Class<?> instanceClass = (toClass == null) ? ClassUtil.getUnEnhanced(type.getInstanceClass()) : toClass;

        if( (toClass != null && BaseObject.class.isAssignableFrom(toClass)) ||
            (toClass == null && type != null && BaseObject.class.isAssignableFrom(ClassUtil.getUnEnhanced(type.getInstanceClass()))) ) {

            return BaseObject.create(instanceClass.getName(), Base.getSession().getPartition());
        }

        return ClassUtil.newInstance(instanceClass);
    }

    @Override
    public Object patchInstance(EntityType entityType) {
        BaseObject bo = (BaseObject)BaseObject.createUninitializedFromVariant(
            entityType.getInstanceClass().getName(), Base.getSession().getVariant());
        bo.getBaseMeta(Base.getSession().getVariant());
        bo.setupBaseObject();

        return bo;
    }
}
