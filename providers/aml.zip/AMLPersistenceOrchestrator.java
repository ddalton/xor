package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseId;
import ariba.base.core.ClusterRoot;
import ariba.base.core.PartitionRuntime;
import ariba.base.core.aql.AQLClassReference;
import ariba.base.core.aql.AQLCondition;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.base.meta.server.SchemaContext;
import ariba.server.jdbcserver.JDBCConnection;
import tools.xor.BusinessObject;
import tools.xor.EntityType;
import tools.xor.Property;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.operation.MigrateOperation;
import tools.xor.service.AbstractPersistenceOrchestrator;
import tools.xor.service.AggregateManager;
import tools.xor.service.EntityScroll;
import tools.xor.service.QueryCapability;
import tools.xor.util.ClassUtil;
import tools.xor.view.NativeQuery;
import tools.xor.view.Query;
import tools.xor.view.QueryViewProperty;
import tools.xor.view.StoredProcedure;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AMLPersistenceOrchestrator extends AbstractPersistenceOrchestrator
{

	private JDBCConnection getJDBCConnection() {
		JDBCConnection jdbcConnection = SchemaContext.getSchemaContext().getJDBCServer().jdbcConnection();

		return jdbcConnection;
	}

	private void release(JDBCConnection jdbcConnection) {
		try {
			if (jdbcConnection != null) {
				jdbcConnection.release();
			}
		}
		finally {
			if (jdbcConnection != null) {
				SchemaContext.getSchemaContext().getJDBCServer().release(jdbcConnection);
			}
		}
	}

	/**
	 * Save the entity in the persistence store
	 * 
	 * @param entity
	 * @return
	 */
	@Override
	public void saveOrUpdate(Object entity) {
		Base.getSession().save((ClusterRoot) entity);
	}

	@Override protected void createStatement (StoredProcedure sp)
	{
		JDBCConnection jdbcConnection = null;
		try {
			jdbcConnection = getJDBCConnection();
			Connection connection = jdbcConnection.getConnection();
			DatabaseMetaData dbmd = connection.getMetaData();
			if(!dbmd.supportsStoredProcedures()) {
				throw new UnsupportedOperationException("Stored procedures with JDBC escape syntax is not supported");
			}

			if(sp.isImplicit()) {
				sp.setStatement(connection.createStatement());
			} else {
				sp.setStatement(connection.prepareCall(sp.jdbcCallString()));
			}
		} catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		} finally {
			release(jdbcConnection);
		}
	}

	@Override
	public void clear() {
		//BaseId[] ids = ((ObjectServerSession)Base.getSession()).getOrderedLocalObjectIds();
		//Base.getSession().removeObjectsFromSession(new HashSet<BaseId>(Arrays.asList(ids)));
  		Base.getSession().transactionRollback();
	}

	@Override
	public void clear(Set<Object> businessObjects) {
		Set<Object> ids = new HashSet<>();
		for(Object bo: businessObjects) {
			if(bo instanceof BusinessObject) {
				ids.add(((BusinessObject)bo).getIdentifierValue());
			}
		}

		Base.getSession().removeObjectsFromSession(ids);
	}
	
	@Override 
	public void refresh(Object object) {
		((ClusterRoot) object).updateVersionIfNecessary();
	}

	/**
	 * Delete the entity from the persistence store
	 * 
	 * @param entity
	 */
	@Override
	public void delete(Object entity) {
		Base.getSession().delete((ClusterRoot)entity);
	}

	@Override
	public void flush() {
		Base.getSession().transactionFlush();
	}

	/**
	 * Flushing is explicitly performed and so this is not relevant.
	 *
	 * @return
	 */
	@Override
	public Object disableAutoFlush() {
		return null;
	}

	@Override
	public void setFlushMode(Object flushMode) {
		throw new UnsupportedOperationException();
	}

	@Override
	protected boolean isTransient(BusinessObject from) {
		Object objectInstance = from.getInstance();

		if(from.getInstance() != null && from.getInstance() instanceof ClusterRoot) {
			// An object that is saved or that is loaded from the DB has this flag true
			return !((ClusterRoot)from.getInstance()).isSaved();
		}

		return false;
	}

	@Override
	public Object findById(Class<?> persistentClass, Object id) {
		return Base.getSession().objectIfAny((BaseId) id);
	}

	@Override public List<Object> findByIds (EntityType entityType, Collection ids)
	{
		if (ids != null && ids.size() > 0) {
            /*
                Batch fetch the objects into cache to avoid loading them one by one.
            */
			Base.getSession().objectsFromIds(new ArrayList(ids));
			List result = new ArrayList<>();
			for (Object bid : ids) {

				if( !(bid instanceof BaseId)) {
					throw new RuntimeException("findByIds needs a collection of BaseIds, but instead got an object of type: " + bid.getClass().getName());
				}

				BaseId baseId = (BaseId) bid;
				if (baseId != null) {
					ClusterRoot cr = baseId.getIfAny();
					if (cr != null) {
						result.add(cr);
					}
				}
			}
			return result;
		}
		return null;
	}

	private List<Object> getResult(Type type, Map<String, Object> propertyValues) {

		AQLClassReference reference =
			new AQLClassReference(type.getInstanceClass().getName(), null, false,
				null, true, true);
		AQLQuery query = new AQLQuery(reference);

		AQLCondition condition = null;
		for(String property: propertyValues.keySet()) {
			AQLCondition c = AQLCondition.buildEqual(
				reference.buildField(property),
				propertyValues.get(property));

			if (condition != null) {
				condition = condition.and(c);
			} else {
				condition = c;
			}
		}
		query.setWhere(condition);

		PartitionRuntime partitionRuntime = Base.getService().getPartitionRuntime();
		AQLOptions options = new AQLOptions(partitionRuntime.getNonePartitionFor(Base.getSession().getRealm()));
        /* State our desire that the query be run with database session in user locale. */
		options.setUserLocale(Base.getSession().getLocale());

		AQLResultCollection result = Base.getService().executeQuery(query, options);
		return result.getRawResults();
	}
	
	@Override
	public Object findByProperty(Type type, Map<String, Object> propertyValues) {

		Object result = null;

		List<String> naturalKey = ((AMLType)type).getNaturalKey();
		if(naturalKey != null && propertyValues.keySet().containsAll(naturalKey)) {
			Object[] values = new Object[naturalKey.size()];
			for(int i=0; i<naturalKey.size(); i++) {
				values[i] = propertyValues.get(naturalKey.get(i));
			}
			result = Base.getSession().objectFromLookupKeys(values, type.getInstanceClass().getName(), Base.getSession().getPartition());
		}

		if(result == null) {
			List<Object> resultList = getResult(type, propertyValues);
			if (resultList != null && !resultList.isEmpty()) {
				result = ((BaseId)((Object[])resultList.get(0))[0]).get();
			}
		}

		return result;
	}

	@Override public Object getCollection (Type type, Map<String, Object> collectionOwnerKey)
	{
		List<Object> resultList = getResult(type, collectionOwnerKey);
		Set<Object> result = new HashSet<Object>(resultList);
		return result;
	}

	@Override
	public QueryCapability getQueryCapability() {
		return new AMLQueryCapability();
	}


	@Override
	public Object getCached(Class<?> persistentClass, Object id)
	{
		return Base.getSession().objectIfCached((BaseId) id);
	}

	@Override public Query getQuery (String s,
									 QueryType queryType,
									 Object queryInput,
									 Settings settings)
	{
		Query result = null;
		switch(queryType) {
		case OQL:
			AQLQuery aQuery = AQLQuery.parseQuery(s);
			result = new AMLQuery(aQuery);
			break;

		case SQL:
			if(settings.getSessionContext() != null) {
				result = ((AMLBatchContext)settings.getSessionContext()).getQuery();
				if(result != null) {
					((AMLQuery)result).reset();
				} else {
					result =  new AMLQuery(s, (NativeQuery) queryInput);
				}
			} else {
				result = new AMLQuery(s, (NativeQuery)queryInput);
			}
			break;

		case SP:
			throw new UnsupportedOperationException("Store procedure is not supported");

		default:
			throw new RuntimeException("Unsupported queryType: " + queryType.name());
		}

		return result;
	}

	@Override
	protected void performAttach(BusinessObject input, Object instance) {
		// reattaches the object to the session
		if(instance instanceof ClusterRoot) {
			ClusterRoot cr = (ClusterRoot) instance;
			cr.id = (BaseId)input.getIdentifierValue();
			cr.reconstitute();

			// reattaches the object to the session
			cr.save();
		}
	}
	
	@Override
	public boolean supportsStoredProcedure() {
		return false;
	}

	@Override public Blob createBlob ()
	{
		JDBCConnection jdbcConnection = null;
		try {
			jdbcConnection = getJDBCConnection();
			return jdbcConnection.getConnection().createBlob();
		}
		catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		} finally {
			release(jdbcConnection);
		}
	}

	@Override
	public EntityScroll getEntityScroll(AggregateManager source, AggregateManager target, Settings settings)
	{
		return new AMLEntityScroll(settings, source, target);
	}

	@Override
	public MigrateOperation getMigrateOperation(AggregateManager source, AggregateManager target, Integer queueSize)
	{
		return new AMLMigrateOperation(source, target, queueSize);
	}

	@Override
	public String getOQLJoinFragment(QueryViewProperty viewProperty) {
		return " LEFT OUTER JOIN " + viewProperty.getType().getName() + " AS "
			+ viewProperty.getAlias() + " SUBCLASS NONE USING "
			+ viewProperty.getNormalizedName();
	}

	@Override
	public String getPolymorphicClause(Class<?> entityClass) {
		// By default we do not retrieve subtype instances. Mainly used by migrate code
		// where this is manually controlled
		return "SUBCLASS NONE";
	}

	@Override
	public void persistSurrogateMap(Map<String, String> surrogateKeyMap) {
		JDBCConnection jdbcConnection = null;
		try {
			jdbcConnection = getJDBCConnection();
			persistMapToTable(jdbcConnection.getConnection(), surrogateKeyMap);
		}
		catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		} finally {
			release(jdbcConnection);
		}
	}

	@Override
	protected Set<String> getSurrogateKeyPaths(Set<String> migratePropertyPaths, EntityType entityType) {
		Set<String> result = new HashSet<>();

		for(String path: migratePropertyPaths) {
			Property property = entityType.getProperty(path);
			if(property.getType().getInstanceClass() == BaseId.class) {
				result.add(path);
			}
		}

		// The surrogateKey is not available at this point since that object is currently
		// being processed
		if(entityType.getIdentifierProperty() != null) {
			String surrogateKeyName = entityType.getIdentifierProperty().getName();
			if (result.contains(surrogateKeyName)) {
				result.remove(surrogateKeyName);
			}
		}

		return result;
	}

	@Override
	public Map<String, String> findMigratedSurrogateIds(Set<String> sourceSurrogateIds) {
		JDBCConnection jdbcConnection = null;
		try {
			jdbcConnection = getJDBCConnection();
			return queryMigratedIds(jdbcConnection.getConnection(), sourceSurrogateIds);
		}
		catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		} finally {
			release(jdbcConnection);
		}
	}
}
