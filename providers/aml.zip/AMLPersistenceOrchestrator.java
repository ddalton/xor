package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseId;
import ariba.base.core.BaseObject;
import ariba.base.core.ClusterRoot;
import ariba.base.core.PartitionRuntime;
import ariba.base.core.aql.AQLClassReference;
import ariba.base.core.aql.AQLCondition;
import ariba.base.core.aql.AQLFieldExpression;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.base.server.BaseServer;
import ariba.server.jdbcserver.JDBCConnection;
import ariba.ui.aribaweb.util.AWEvaluateTemplateFile;
import ariba.util.fieldvalue.FieldValue;
import org.hibernate.LockOptions;
import test.ariba.base.core.DegreeProgram;
import tools.xor.AbstractBO;
import tools.xor.BusinessObject;
import tools.xor.EntityType;
import tools.xor.ExtendedProperty;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.service.AbstractPersistenceOrchestrator;
import tools.xor.service.QueryCapability;
import tools.xor.util.ClassUtil;
import tools.xor.util.ObjectCreator;
import tools.xor.view.AggregateView;
import tools.xor.view.NativeQuery;
import tools.xor.view.Query;
import tools.xor.view.StoredProcedure;

import javax.persistence.LockModeType;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AMLPersistenceOrchestrator extends AbstractPersistenceOrchestrator
{

	/**
	 * Save the entity in the persistence store
	 * 
	 * @param entity
	 * @return
	 */
	@Override
	public void saveOrUpdate(Object entity) {
		Base.getSession().save((ClusterRoot) entity);
	}

	@Override protected void createStatement (StoredProcedure sp)
	{
		try {
			JDBCConnection jdbcConnection = BaseServer.baseServer().getDefaultJDBCServer().getJDBCConnection();
			Connection connection = jdbcConnection.getConnection();
			DatabaseMetaData dbmd = connection.getMetaData();
			if(!dbmd.supportsStoredProcedures()) {
				throw new UnsupportedOperationException("Stored procedures with JDBC escape syntax is not supported");
			}

			if(sp.isImplicit()) {
				sp.setStatement(connection.createStatement());
			} else {
				sp.setStatement(connection.prepareCall(sp.jdbcCallString()));
			}
		} catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		}
	}

	@Override
	public void clear() {
		//BaseId[] ids = ((ObjectServerSession)Base.getSession()).getOrderedLocalObjectIds();
		//Base.getSession().removeObjectsFromSession(new HashSet<BaseId>(Arrays.asList(ids)));
  		Base.getSession().transactionRollback();
	}

	@Override
	public void clear(Set<Object> businessObjects) {
		Set<Object> ids = new HashSet<>();
		for(Object bo: businessObjects) {
			if(bo instanceof BusinessObject) {
				ids.add(((BusinessObject)bo).getIdentifierValue());
			}
		}

		Base.getSession().removeObjectsFromSession(ids);
	}
	
	@Override 
	public void refresh(Object object) {
		((ClusterRoot) object).updateVersionIfNecessary();
	}

	/**
	 * Delete the entity from the persistence store
	 * 
	 * @param entity
	 */
	@Override
	public void delete(Object entity) {
		Base.getSession().delete((ClusterRoot)entity);
	}

	@Override
	public void flush() {
		Base.getSession().transactionFlush();
	}

	/**
	 * Flushing is explicitly performed and so this is not relevant.
	 *
	 * @return
	 */
	@Override
	public Object disableAutoFlush() {
		return null;
	}

	@Override
	public void setFlushMode(Object flushMode) {
		throw new UnsupportedOperationException();
	}

	@Override
	protected boolean isTransient(BusinessObject from) {
		Object objectInstance = from.getInstance();

		if(from.getInstance() != null && from.getInstance() instanceof ClusterRoot) {
			// An object that is saved or that is loaded from the DB has this flag true
			return !((ClusterRoot)from.getInstance()).isSaved();
		}

		return false;
	}

	@Override
	public Object findById(Class<?> persistentClass, Object id) {
		return Base.getSession().objectIfAny((BaseId) id);
	}

	@Override public List<Object> findByIds (EntityType entityType, Collection ids)
	{
		if (ids != null && ids.size() > 0) {
            /*
                Batch fetch the objects into cache to avoid loading them one by one.
            */
			Base.getSession().objectsFromIds(new ArrayList(ids));
			List result = new ArrayList<>();
			for (Object bid : ids) {

				if( !(bid instanceof BaseId)) {
					throw new RuntimeException("findByIds needs a collection of BaseIds, but instead got an object of type: " + bid.getClass().getName());
				}

				BaseId baseId = (BaseId) bid;
				if (baseId != null) {
					ClusterRoot cr = baseId.getIfAny();
					if (cr != null) {
						result.add(cr);
					}
				}
			}
			return result;
		}
		return null;
	}

	private List<Object> getResult(Type type, Map<String, Object> propertyValues) {

		AQLClassReference reference =
			new AQLClassReference(type.getInstanceClass().getName(), null, false,
				null, true, true);
		AQLQuery query = new AQLQuery(reference);

		AQLCondition condition = null;
		for(String property: propertyValues.keySet()) {
			AQLCondition c = AQLCondition.buildEqual(
				reference.buildField(property),
				propertyValues.get(property));

			if (condition != null) {
				condition = condition.and(c);
			} else {
				condition = c;
			}
		}
		query.setWhere(condition);

		PartitionRuntime partitionRuntime = Base.getService().getPartitionRuntime();
		AQLOptions options = new AQLOptions(partitionRuntime.getNonePartitionFor(Base.getSession().getRealm()));
        /* State our desire that the query be run with database session in user locale. */
		options.setUserLocale(Base.getSession().getLocale());

		AQLResultCollection result = Base.getService().executeQuery(query, options);
		return result.getRawResults();
	}
	
	@Override
	public Object findByProperty(Type type, Map<String, Object> propertyValues) {

		Object result = null;

		List<String> naturalKey = ((AMLType)type).getNaturalKey();
		if(naturalKey != null && propertyValues.keySet().containsAll(naturalKey)) {
			Object[] values = new Object[naturalKey.size()];
			for(int i=0; i<naturalKey.size(); i++) {
				values[i] = propertyValues.get(naturalKey.get(i));
			}
			result = Base.getSession().objectFromLookupKeys(values, type.getInstanceClass().getName(), Base.getSession().getPartition());
		}

		if(result == null) {
			List<Object> resultList = getResult(type, propertyValues);
			if (resultList != null && !resultList.isEmpty()) {
				result = ((BaseId)((Object[])resultList.get(0))[0]).get();
			}
		}

		return result;
	}

	@Override public Object getCollection (Type type, Map<String, Object> collectionOwnerKey)
	{
		List<Object> resultList = getResult(type, collectionOwnerKey);
		Set<Object> result = new HashSet<Object>(resultList);
		return result;
	}

	@Override
	public QueryCapability getQueryCapability() {
		return new AMLQueryCapability();
	}


	@Override
	public Object getCached(Class<?> persistentClass, Object id)
	{
		return Base.getSession().objectIfCached((BaseId) id);
	}

	@Override public Query getQuery (String s,
									 QueryType queryType,
									 Object queryInput,
									 Settings settings)
	{
		Query result = null;
		switch(queryType) {
		case OQL:
			AQLQuery aQuery = AQLQuery.parseQuery(s);
			result = new AMLQuery(aQuery);
			break;

		case SQL:
			if(settings.getSessionContext() != null) {
				return ((AMLBatchContext)settings.getSessionContext()).getQuery();
			}
			result = new AMLQuery(s, (NativeQuery) queryInput);
			break;

		case SP:
			throw new UnsupportedOperationException("Store procedure is not supported");

		default:
			throw new RuntimeException("Unsupported queryType: " + queryType.name());
		}

		return result;
	}

	@Override
	protected void performAttach(BusinessObject input, Object instance) {
		// reattaches the object to the session
		if(instance instanceof ClusterRoot) {
			ClusterRoot cr = (ClusterRoot) instance;
			cr.id = (BaseId)input.getIdentifierValue();
			cr.reconstitute();

			// reattaches the object to the session
			cr.save();
		}
	}
	
	@Override
	public boolean supportsStoredProcedure() {
		return false;
	}

	@Override public Blob createBlob ()
	{
		JDBCConnection jdbcConnection = BaseServer.baseServer().getDefaultJDBCServer().getJDBCConnection();
		Connection connection = jdbcConnection.getConnection();
		try {
			return connection.createBlob();
		}
		catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		}
	}
}
