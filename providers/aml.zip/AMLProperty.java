package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.BaseObject;
import ariba.base.meta.server.ClassMappingSupport;
import ariba.base.meta.server.FieldMetaDT;
import ariba.base.server.BaseServer;
import ariba.util.core.FatalAssertionException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import tools.xor.AbstractProperty;
import tools.xor.EntityType;
import tools.xor.Property;
import tools.xor.RelationshipType;
import tools.xor.StringType;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.service.Shape;
import tools.xor.util.ClassUtil;
import tools.xor.util.Constants;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AMLProperty extends AbstractProperty
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());

	private static final String IGNORE_BINFE = "exception.BaseIdNotFoundException.ignore";

	private FieldMetaDT fieldMetaDT;
	private Boolean     cascaded;

	public AMLProperty(FieldMetaDT fieldMetaDT, Type type, AMLType parentType) {
		super(type, parentType);
		this.fieldMetaDT = fieldMetaDT;

		if(type instanceof StringType) {
			int length = fieldMetaDT.getType().getLength();

			int origlen = length;

			if (length > 0) {
				Collection cols = ClassMappingSupport.getClassMappingSupport().getFieldMappings(fieldMetaDT);
				if(cols != null && !cols.isEmpty()) {
					int truncatedLength = BaseServer.baseServer().getTruncatedStringFieldLength(
						fieldMetaDT);
					length = Math.min(length, truncatedLength);
				}
			}

			// force a max limit to avoid issues with the truncated length conflicting with the
			// actual schema column length
			if(length > 2000) {
				length = 2000;
			}

			//if("Name".equals(fieldMetaDT.name())) {
			//	System.out.println("**** Original length: " + origlen + ", truncated: " + length + ", parent Type: " + parentType.getName());
			//}

			addConstraint(Constants.XOR.CONS_LENGTH, length);
		}
		if (fieldMetaDT.getType().hasPrecisionAndScale()) {
			int scale = fieldMetaDT.getType().getScale();
			addConstraint(Constants.XOR.CONS_SCALE, scale);

			int precision = fieldMetaDT.getType().getPrecision();
			addConstraint(Constants.XOR.CONS_PRECISION, precision-scale);
		}

		init();		
	}

	public AMLProperty (String itemList, Type type, AMLType spType)
	{
		super(itemList, type, spType);
	}

	public AMLProperty(String name, Type type, EntityType parentType, RelationshipType relType, EntityType elementType) {
		super(name, type, parentType, relType, elementType);
	}

	@Override
	public String getName() {
		if(!isOpenContent() || fieldMetaDT != null) {
			return fieldMetaDT.name();
		} else {
			return this.name;
		}
	}

	@Override
	public boolean isMany() {

		if(fieldMetaDT != null) {
			return fieldMetaDT.isVector();
		}

		if(isOpenContent()) {
			return getRelationshipType() == RelationshipType.TO_MANY;
		} else {
			return false;
		}
	}

	@Override
	public boolean isContainment() {
		if(!isOpenContent() || fieldMetaDT != null) {
			if (fieldMetaDT.type().isVector() && fieldMetaDT.type().isClusterRoot()) {
				return false;
			}

			if (fieldMetaDT.type().isClusterRoot()) {
				return false;
			}
		}

		if(isOpenContent()) {
			return super.isContainment();
		}

		return true;
	}

	/**
	 * Not directly supported in Hibernate
	 */
	@Override
	public Object getDefault() {
		return null;
	}

	@Override
	public boolean isReadOnly() {
		boolean result = false;

		if(!isOpenContent() && fieldMetaDT != null) {
			result = fieldMetaDT.isDerived() || !fieldMetaDT.isPersistent();
		}

		return result || super.isReadOnly();
	}

	@Override
	public boolean isNullable() {
		if(!isOpenContent() && fieldMetaDT != null) {
			return fieldMetaDT.isNullAllowed();
		} else {
			return true;
		}
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}		

	@Override
	public void init(Shape shape) {

		if(isMany()) { // Only Vector type is supported
			// The index is ColumnMetaDT.VectorIndexName which is of Integer type
			keyType = shape.getType(Integer.class);
			elementType = shape.getType(fieldMetaDT.getType().getClassName());
		}
	}

	@Override
	public boolean isIdentifier() {
		return fieldMetaDT != null && BaseObject.KeyBaseId.equals(fieldMetaDT.name());
	}

	@Override public boolean isCollectionOfReferences ()
	{
		return fieldMetaDT.isVector() && fieldMetaDT.hasClusterRootType();
	}

	@Override public boolean isOpenContent ()
	{
		if(isIdentifier()) {
			return false;
		}

		boolean open = super.isOpenContent();

		if(!open) {
			// check FieldMetaDT to see if it is a derived property,
			// We consider derived as open properties
			if(fieldMetaDT.isDerived() || fieldMetaDT.isTemplate() || fieldMetaDT.isNoPersist()) {
				open = true;
			}
		}

		return open;
	}

	@Override
	protected void initByAnnotations() {
		// JPA annotations not supported in AML
	}

	@Override
	public void initMappedBy(DataAccessService das) {
		// This is not supported in AML
	}

	@Override
	public boolean isMap() {
		// Only the List type is supported
		return false;
	}

	@Override
	public boolean isList() {
		// If this is a AML vector property only
		if(isMany() && name == null)
		{
			return true;
		}

		return false;
	}

	@Override
	public boolean isSet() {
		// Supported only for open type collections
		if(isMany() && name != null) {
			return true;
		}

		return false;
	}

	@Override
	public boolean isManaged() {
		if(fieldMetaDT == null) {
			return super.isManaged();
		}

		return fieldMetaDT.isExtensionField() || fieldMetaDT.isFlex();
	}

	@Override
	public Object query (Object dataObject)
	{
		Object instance = ClassUtil.getInstance(dataObject);
		if (isManaged() && instance instanceof BaseObject) {
			return ((BaseObject)instance).getFieldValue(getName());
		}
		else {
			return super.query(dataObject);
		}
	}

	@Override
	public void executeUpdate(Object dataObject, Object propertyValue) {
		// Check if the setter is meaningful for this property
		if(fieldMetaDT.isNoPersist()) {
			return;
		}

		Object instance = ClassUtil.getInstance(dataObject);
		propertyValue = ClassUtil.getInstance(propertyValue);
		if(isManaged() && instance instanceof BaseObject) {
			if(!isOpenContent() && !fieldMetaDT.isUnused() && !fieldMetaDT.isInstanceField() && !fieldMetaDT.isUnusedInstanceField()) {
				try {
					((BaseObject)instance).setFieldValue(getName(), propertyValue);
				} catch (Exception e) {
					// do nothing - Field is probably not present in this variant
				}
			}
		} else {
			super.executeUpdate(dataObject, propertyValue);
		}
	}
}

