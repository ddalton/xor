package com.sap.ariba.hana.aheap.baseschool.aml;

import java.util.ArrayList;
import java.util.List;

import ariba.base.core.BaseObject;
import ariba.base.meta.server.FieldMetaDT;
import ariba.util.fieldvalue.FieldValue;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import tools.xor.AbstractProperty;
import tools.xor.ExtendedProperty;
import tools.xor.Property;
import tools.xor.StringType;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.service.Shape;
import tools.xor.util.ClassUtil;
import tools.xor.util.Constants;

public class AMLProperty extends AbstractProperty
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());	

	private FieldMetaDT fieldMetaDT;
	private Boolean     cascaded;

	public AMLProperty(FieldMetaDT fieldMetaDT, Type type, AMLType parentType) {
		super(type, parentType);
		this.fieldMetaDT = fieldMetaDT;

		if(type instanceof StringType) {
			addConstraint(Constants.XOR.CONS_LENGTH, fieldMetaDT.getType().getLength()-1);
		}

		init();		
	}

	public AMLProperty (String itemList, Type type, AMLType spType)
	{
		super(itemList, type, spType);
	}

	@Override
	public String getName() {
		if(!isOpenContent() || fieldMetaDT != null) {
			return fieldMetaDT.name();
		} else {
			return this.name;
		}
	}

	@Override
	public boolean isMany() {
		if(!isOpenContent() || fieldMetaDT != null) {
			return fieldMetaDT.isVector();
		} else {
			return false;
		}
	}

	@Override
	public boolean isContainment() {
		if(!isOpenContent() || fieldMetaDT != null) {
			if (fieldMetaDT.type().isVector() && fieldMetaDT.type().isClusterRoot()) {
				return false;
			}

			if (fieldMetaDT.type().isClusterRoot()) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Not directly supported in Hibernate
	 */
	@Override
	public Object getDefault() {
		return null;
	}

	@Override
	public boolean isReadOnly() {
		boolean result = false;

		if(!isOpenContent() && fieldMetaDT != null) {
			result = fieldMetaDT.isDerived() || !fieldMetaDT.isPersistent();
		}

		return result || super.isReadOnly();
	}

	@Override
	public boolean isNullable() {
		if(!isOpenContent() && fieldMetaDT != null) {
			return fieldMetaDT.isNullAllowed();
		} else {
			return true;
		}
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}		

	@Override
	public void init(DataAccessService das, Shape shape) {

		if(isMany()) { // Only Vector type is supported
			// The index is ColumnMetaDT.VectorIndexName which is of Integer type
			keyType = shape.getType(Integer.class);
			elementType = shape.getType(fieldMetaDT.getType().getClassName());
		}
	}

	@Override
	public boolean isIdentifier() {
		return BaseObject.KeyBaseId.equals(fieldMetaDT.name());
	}

	@Override public boolean isCollectionOfReferences ()
	{
		return fieldMetaDT.isVector() && fieldMetaDT.hasClusterRootType();
	}

	@Override public boolean isOpenContent ()
	{
		if(isIdentifier()) {
			return false;
		}

		boolean open = super.isOpenContent();

		if(!open) {
			// check FieldMetaDT to see if it is a derived property,
			// We consider derived as open properties
			if(fieldMetaDT.isDerived() || fieldMetaDT.isTemplate() || fieldMetaDT.isNoPersist()) {
				open = true;
			}
		}

		return open;
	}

	@Override
	protected void initByAnnotations() {
		// JPA annotations not supported in AML
	}

	@Override
	public void initMappedBy(DataAccessService das) {
		// This is not supported in AML
	}

	@Override
	public boolean isMap() {
		// Only the List type is supported
		return false;
	}

	@Override
	public boolean isList() {
		if(isMany())
		{
			return true;
		}

		return false;
	}

	@Override
	public boolean isSet() {
		// Only the List type is supported
		return false;
	}

	@Override
	public boolean isManaged() {
		return fieldMetaDT.isExtensionField();
	}


	@Override
	public Object query(Object dataObject) {
		Object instance = ClassUtil.getInstance(dataObject);
		if(isManaged() && instance instanceof BaseObject) {
			return ((BaseObject) instance).getFieldValue(getName());
		} else {
			return super.query(dataObject);
		}
	}

	@Override
	public void executeUpdate(Object dataObject, Object propertyValue) {
		Object instance = ClassUtil.getInstance(dataObject);
		propertyValue = ClassUtil.getInstance(propertyValue);
		if(isManaged() && instance instanceof BaseObject) {
			if(!isOpenContent() && !fieldMetaDT.isUnused() && !fieldMetaDT.isInstanceField() && !fieldMetaDT.isUnusedInstanceField()) {
				try {
					((BaseObject)instance).setFieldValue(getName(), propertyValue);
				} catch (Exception e) {
					// do nothing - Field is probably not present in this variant
				}
			}
		} else {
			super.executeUpdate(dataObject, propertyValue);
		}
	}
}

