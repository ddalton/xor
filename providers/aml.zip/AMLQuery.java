package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.server.jdbcserver.JDBCConnection;
import ariba.server.jdbcserver.JDBCServer;
import ariba.util.core.ListUtil;
import org.apache.commons.lang.StringUtils;
import tools.xor.view.AbstractQuery;
import tools.xor.view.NativeQuery;
import tools.xor.view.ParameterMapping;
import tools.xor.view.QueryView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AMLQuery extends AbstractQuery
{
	
	private AQLQuery aqlQuery;
	private AQLOptions aqlOptions;
	private String sqlQuery;
	private NativeQuery nativeQuery;

	private List positionalParameters;
	private Map<String, Object> namedParameters;
	private Map<Integer, ParameterMapping> paramMap = new HashMap<Integer, ParameterMapping>();

	private void initOptions()
	{
		// Needed for test
		aqlOptions = new AQLOptions(Base.getService().getPartition("None"));
		aqlOptions.setUserLocale(Locale.US);
	}

	public AMLQuery(AQLQuery query) {
		this.aqlQuery = query;
		initOptions();
	}

	public AMLQuery(String sql, NativeQuery nativeQuery) {
		sqlQuery = sql;
		this.nativeQuery = nativeQuery;

		int position = 1;
		if (nativeQuery.getParameterList() != null) {
			for (ParameterMapping param : nativeQuery.getParameterList()) {
				param.position = position;
				String attrName = param.attribute;
				if (attrName == null) {
					attrName = param.name;
				}
				paramMap.put(position, param);
			}
		}
	}

	private List getResultSet ()
	{
		JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
		JDBCConnection jdbcConnection = jdbcServer.jdbcConnection();
		Connection connection = jdbcConnection.getConnection();
		PreparedStatement statement = null;
		List result = ListUtil.list();

		try {
			statement = connection.prepareStatement(sqlQuery);
			if(positionalParameters != null) {
				for(int i=0; i < positionalParameters.size(); i++ ) {
					if(positionalParameters.get(i) == null) {
						continue;
					}
					// Note JDBC positional parameters start from 1
					paramMap.get(i).setValue(statement, positionalParameters.get(i));
				}
			}

			ResultSet rs = statement.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();
			int NumOfCol = rsmd.getColumnCount();

			List columnLabels = new ArrayList<>(NumOfCol);
			for(int i = 1; i <= NumOfCol; i++) {
				columnLabels.add(rsmd.getColumnLabel(i));
			}
			setColumns(columnLabels);

			while (rs.next()) {
				Object[] row = new Object[NumOfCol];
				for (int i = 1; i <= NumOfCol; i++) {
					row[i - 1] = rs.getObject(i);
				}
				result.add(row);
			}
			rs.close();
		} catch (SQLException se) {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(se);
		} finally {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	private boolean isSQL() {
		return sqlQuery != null;
	}

	private void prepare() {
		if(positionalParameters != null && namedParameters != null) {
			throw new RuntimeException("Either use positional or named parameters but not both");
		}
		if(namedParameters != null) {
			aqlOptions.setActualParameters(namedParameters);
		}
		if(positionalParameters != null) {
			aqlOptions.setActualParameters(positionalParameters);
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getResultList (QueryView queryView)
	{
		List result = ListUtil.list();

		if (!isSQL())
		{
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);

			if (results.getErrors() != null) {
				throw new RuntimeException(results.getFirstError().toString());
			}
			else {
				while (results.next()) {
					result.add(results.getCurrent());
				}
			}
		}
		else {
			result = getResultSet();
		}

		return result;
	}

	@Override
	public Object getSingleResult (QueryView queryView)
	{
		if (!isSQL()) {
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);
			return results.getSingleObject();
		}
		else {
			// Note: the first row is the column label
			List result = getResultSet();
			if (result.size() == 0) {
				return null;
			}
			if (result.size() > 1) {
				throw new RuntimeException("Has more than 1 result");
			}
			else {
				result.get(0);
			}
		}

		return null;
	}

	@Override
	public void setParameter(String name, Object value) {

		boolean isPositional = false;
		if(StringUtils.isNumeric(name)) {
			isPositional = true;
		}

		if(isPositional) {
			if (positionalParameters == null) {
				// We support only a max of 10 parameters
				positionalParameters = new ArrayList<>(10);
			}

			int position = Integer.valueOf(name);
			if(position >= 10) {
				throw new RuntimeException("Supported positional values are from 0-9");
			}
			positionalParameters.add(position, value);

		} else {
			if (namedParameters == null) {
				namedParameters = new HashMap<>();
			}

			namedParameters.put(name, value);
		}
	}

	@Override
	public boolean hasParameter(String name) {
		return namedParameters != null && namedParameters.containsKey(name);
	}

	@Override
	public void setMaxResults(int limit) {
		aqlOptions.setRowLimit(limit);
	}

	@Override
	public void setFirstResult(int offset) {
		throw new UnsupportedOperationException("Offset is not supported, rather give " +
		" last unique key of rows retrieved ordered by this key.");
	}	
}

