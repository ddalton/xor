package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseThread;
import ariba.base.core.BaseThreadImpl;
import ariba.base.core.Partition;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.server.jdbcserver.JDBCConnection;
import ariba.server.jdbcserver.JDBCServer;
import ariba.util.core.ListUtil;
import tools.xor.view.AbstractQuery;
import tools.xor.view.QueryView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Locale;

public class AMLQuery extends AbstractQuery
{
	
	private AQLQuery aqlQuery;
	private AQLOptions aqlOptions;
	private String sqlQuery;
	private Statement statement;

	private void initOptions()
	{
		// Needed for test
		aqlOptions = new AQLOptions(Base.getService().getPartition("None"));
		aqlOptions.setUserLocale(Locale.US);
	}

	public AMLQuery(AQLQuery query) {
		this.aqlQuery = query;
		initOptions();
	}

	public AMLQuery (String sql)
	{
		sqlQuery = sql;
	}

	private List getResultSet ()
	{
		JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
		JDBCConnection jdbcConnection = jdbcServer.jdbcConnection();
		Connection connection = jdbcConnection.getConnection();
		PreparedStatement statement = null;
		List result = ListUtil.list();

		try {
			statement = connection.prepareStatement(sqlQuery);
			ResultSet rs = statement.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();
			int NumOfCol = rsmd.getColumnCount();

			while (rs.next()) {
				Object[] row = new Object[NumOfCol];
				for (int i = 1; i <= NumOfCol; i++) {
					row[i - 1] = rs.getObject(i);
				}
				result.add(row);
			}
			rs.close();
		} catch (SQLException se) {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(se);
		} finally {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	private boolean isSQL() {
		return sqlQuery != null;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getResultList (QueryView queryView)
	{
		List result = ListUtil.list();

		if (!isSQL())
		{
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);

			if (results.getErrors() != null) {
				throw new RuntimeException(results.getFirstError().toString());
			}
			else {
				while (results.next()) {
					result.add(results.getCurrent());
				}
			}
		}
		else {
			result = getResultSet();
		}

		return result;
	}

	@Override
	public Object getSingleResult (QueryView queryView)
	{
		if (!isSQL()) {
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);
			return results.getSingleObject();
		}
		else {
			List result = getResultSet();
			if (result.size() == 0) {
				return null;
			}
			if (result.size() > 1) {
				throw new RuntimeException("Has more than 1 result");
			}
			else {
				result.get(0);
			}
		}

		return null;
	}

	@Override
	public void setParameter(String name, Object value) {
		throw new UnsupportedOperationException("Query parameters are not supported in AQL");
	}

	@Override
	public boolean hasParameter(String name) {
		throw new UnsupportedOperationException("Query parameters are not supported in AQL");
	}

	@Override
	public void setMaxResults(int limit) {
		aqlOptions.setRowLimit(limit);
	}

	@Override
	public void setFirstResult(int offset) {
		throw new UnsupportedOperationException("Offset is not supported, rather give " +
		" last unique key of rows retrieved ordered by this key.");
	}	
}

