package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.Partition;
import ariba.base.core.aql.AQLGenerateException;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.base.core.aql.AQLSelectElement;
import ariba.base.core.aql.AQLValidateException;
import ariba.base.server.BaseServer;
import ariba.base.server.aql.AQLGenerator;
import ariba.base.server.aql.AQLQueryPlan;
import ariba.server.jdbcserver.JDBCConnection;
import ariba.server.jdbcserver.JDBCServer;
import ariba.server.jdbcserver.SchemaPrefixRemover;
import ariba.util.core.ListUtil;
import org.apache.commons.lang.StringUtils;
import tools.xor.AggregateAction;
import tools.xor.Settings;
import tools.xor.util.ClassUtil;
import tools.xor.view.AbstractQuery;
import tools.xor.view.BindParameter;
import tools.xor.view.NativeQuery;
import tools.xor.view.View;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class AMLQuery extends AbstractQuery
{
	
	private AQLQuery aqlQuery;
	private AQLOptions aqlOptions;
	private String sqlQuery;
	private NativeQuery nativeQuery;

	private Map<Integer, Object> positionalParameters;
	private Map<String, Object> namedParameters;
	private Map<Integer, BindParameter> paramMap = new HashMap<Integer, BindParameter>();

	// Needed to support JDBC batching
	// We share the AMLQuery instance
	private JDBCConnection jdbcConnection = null;
	private Connection connection = null;
	private PreparedStatement statement = null;

	private void initOptions()
	{
		// Needed for test
		aqlOptions = new AQLOptions(Partition.Any);
		aqlOptions.setUserLocale(Locale.US);

		// Initialize columns if necessary
		if(getColumns() == null || getColumns().size() == 0) {
			if (aqlQuery != null) {
				List selectElements = aqlQuery.getSelectList();
				List selectedColumns = new ArrayList<>(selectElements.size());
				for (int i=0, size=selectElements.size(); i < size; ++i)
				{
					AQLSelectElement element = (AQLSelectElement)selectElements.get(i);
					selectedColumns.add(element.toString());
				}
				setColumns(selectedColumns);
			}
		}
	}

	public AMLQuery(AQLQuery query) {
		this.aqlQuery = query;
		initOptions();
	}

	public AMLQuery(String sql, NativeQuery nativeQuery) {
		sqlQuery = sql;
		this.nativeQuery = nativeQuery;

		initParamMap();
	}

	private void initParamMap() {
		int position = 1;
		if (nativeQuery.getParameterList() != null) {
			for (BindParameter param : nativeQuery.getParameterList()) {
				param.position = position;
				paramMap.put(position++, param);
			}
		}
	}

	private List getResultSet (Settings settings)
	{
		JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
		JDBCConnection jdbcConnection = jdbcServer.jdbcConnection();
		Connection connection = jdbcConnection.getConnection();
		PreparedStatement statement = null;
		List result = ListUtil.list();

		try {
			statement = connection.prepareStatement(sqlQuery);
			setPositionalParameters(settings, positionalParameters, paramMap, statement);

			ResultSet rs = statement.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();
			int NumOfCol = rsmd.getColumnCount();

			List columnLabels = new ArrayList<>(NumOfCol);
			for(int i = 1; i <= NumOfCol; i++) {
				columnLabels.add(rsmd.getColumnLabel(i));
			}
			setColumns(columnLabels);

			while (rs.next()) {
				Object[] row = new Object[NumOfCol];
				for (int i = 1; i <= NumOfCol; i++) {
					row[i - 1] = rs.getObject(i);
				}
				result.add(row);
			}
			rs.close();
		} catch (SQLException se) {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(se);
		} finally {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	private int executeUpdate (Settings settings)
	{
		// Check if batching is enabled
		NativeQuery nq = settings.getView().getNativeQuery();

		int result = 0;
		AMLBatchContext context = (AMLBatchContext)settings.getSessionContext();
		try {
			if(statement == null) {
				JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
				jdbcConnection = jdbcServer.jdbcConnection();
				connection = jdbcConnection.getConnection();
				statement = connection.prepareStatement(sqlQuery);
				if(context != null) {
					context.setQuery(this);
				}

				// We will try to auto discover the types of the columns being inserted
				if(nq.getParameterList() == null) {
					if (settings.getAction() == AggregateAction.CREATE) {
						nq.setParameterList(autoDiscoverInsert(connection, sqlQuery));
						initParamMap();
					} else {
						throw new RuntimeException("Bind variable types need to be specified");
					}
				}
			}
			setPositionalParameters(settings, positionalParameters, paramMap, statement);

			if (context != null) {
				if(context.isShouldBatch()) {
					statement.addBatch();
				} else {
					// last command in the batch
					statement.addBatch();
					// Return a negative value to signify the number of batch SQLs executed
					result = statement.executeBatch().length * -1;
					context.setQuery(null);
				}
			} else {
				result = statement.executeUpdate();
			}
		} catch (SQLException se) {
			throw ClassUtil.wrapRun(se);
		}

		return result;
	}

	private boolean isSQL() {
		return sqlQuery != null;
	}

	private void prepare() {
		if(positionalParameters != null && namedParameters != null) {
			throw new RuntimeException("Either use positional or named parameters but not both");
		}
		if(namedParameters != null) {
			aqlOptions.setActualParameters(namedParameters);
		}
		if(positionalParameters != null) {
			List paramList = new ArrayList<>(positionalParameters.values());
			aqlOptions.setActualParameters(paramList);
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getResultList (View view, Settings settings)
	{
		List result = ListUtil.list();

		if (!isSQL())
		{
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);

			if (results.getErrors() != null) {
				throw new RuntimeException(results.getFirstError().toString());
			}
			else {
				while (results.next()) {
					result.add(results.getCurrent());
				}
			}
		}
		else {
			result = getResultSet(settings);
		}

		return result;
	}

	@Override
	public Object getSingleResult (View view, Settings settings)
	{
		if (!isSQL()) {
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);
			return results.getSingleObject();
		}
		else {
			// Note: the first row is the column label
			List result = getResultSet(settings);
			if (result.size() == 0) {
				return null;
			}
			if (result.size() > 1) {
				throw new RuntimeException("Has more than 1 result");
			}
			else {
				return result.get(0);
			}
		}
	}

	@Override
	public void setParameter(String name, Object value) {

		boolean isPositional = false;
		if(StringUtils.isNumeric(name)) {
			isPositional = true;
		}

		if(isPositional) {
			if (positionalParameters == null) {
				// Sort the parameters by its position
				positionalParameters = new TreeMap<>();
			}

			int position = Integer.valueOf(name);
			positionalParameters.put(position, value);

		} else {
			if (namedParameters == null) {
				namedParameters = new HashMap<>();
			}

			namedParameters.put(name, value);
		}
	}

	/**
	 * Reset the query to prepare to process the next set of bind values for the
	 * next DML in the batch
	 */
	public void reset() {
		if(positionalParameters != null) {
			positionalParameters.clear();
		}
		if(namedParameters != null) {
			namedParameters.clear();
		}
	}

	@Override
	public boolean hasParameter(String name) {
		return namedParameters != null && namedParameters.containsKey(name);
	}

	@Override public Object execute (Settings settings)
	{
		if(settings.getAction() != AggregateAction.READ) {
			return executeUpdate(settings);

		} else {
			return getResultList(null, settings);
		}
	}

	public String convertToSQL() {
		String result = null;

		try {
			result = BaseServer.baseServer().objectSource.generateQuery(
                aqlQuery, aqlOptions, false).getSQLString();

			result = (new SchemaPrefixRemover()).modifyStatement(result);
		}
		catch (AQLValidateException e) {
			e.printStackTrace();
		}
		catch (AQLGenerateException e) {
			e.printStackTrace();
		}

		return result;
/*
		AQLGenerator generatorHana = new AQLGenerator(BaseServer.baseServer());
		// Retrieve data from all partitions
		aqlOptions.setPartition(Partition.Any);
		AQLQueryPlan aqlQueryPlan = null;
		try {
			aqlQueryPlan = (AQLQueryPlan) generatorHana.generate(aqlQuery, aqlOptions);
			aqlQueryPlan.setOptions(aqlOptions);
			aqlQueryPlan.generate();
		}
		catch (AQLGenerateException e) {
			e.printStackTrace();
		}

		return aqlQueryPlan.getStatementBuffer().toString();
		*/
	}

	@Override
	public void setMaxResults(int limit) {
		aqlOptions.setRowLimit(limit);
	}

	@Override
	public void setFirstResult(int offset) {
		throw new UnsupportedOperationException("Offset is not supported, rather give " +
		" last unique key of rows retrieved ordered by this key.");
	}	
}

