package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.aql.AQLOptions;
import ariba.base.core.aql.AQLQuery;
import ariba.base.core.aql.AQLResultCollection;
import ariba.base.core.aql.AQLSelectElement;
import ariba.server.jdbcserver.JDBCConnection;
import ariba.server.jdbcserver.JDBCServer;
import ariba.util.core.ListUtil;
import org.apache.commons.lang.StringUtils;
import tools.xor.AggregateAction;
import tools.xor.Settings;
import tools.xor.view.AbstractQuery;
import tools.xor.view.NativeQuery;
import tools.xor.view.ParameterMapping;
import tools.xor.view.QueryView;
import tools.xor.view.View;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class AMLQuery extends AbstractQuery
{
	
	private AQLQuery aqlQuery;
	private AQLOptions aqlOptions;
	private String sqlQuery;
	private NativeQuery nativeQuery;

	private Map<Integer, Object> positionalParameters;
	private Map<String, Object> namedParameters;
	private Map<Integer, ParameterMapping> paramMap = new HashMap<Integer, ParameterMapping>();

	// Needed to support JDBC batching
	// We share the AMLQuery instance
	private JDBCConnection jdbcConnection = null;
	private Connection connection = null;
	private PreparedStatement statement = null;

	private void initOptions()
	{
		// Needed for test
		aqlOptions = new AQLOptions(Base.getService().getPartition("None"));
		aqlOptions.setUserLocale(Locale.US);

		// Initialize columns if necessary
		if(getColumns() == null || getColumns().size() == 0) {
			if (aqlQuery != null) {
				List selectElements = aqlQuery.getSelectList();
				List selectedColumns = new ArrayList<>(selectElements.size());
				for (int i=0, size=selectElements.size(); i < size; ++i)
				{
					AQLSelectElement element = (AQLSelectElement)selectElements.get(i);
					selectedColumns.add(element.toString());
				}
				setColumns(selectedColumns);
			}
		}
	}

	public AMLQuery(AQLQuery query) {
		this.aqlQuery = query;
		initOptions();
	}

	public AMLQuery(String sql, NativeQuery nativeQuery) {
		sqlQuery = sql;
		this.nativeQuery = nativeQuery;

		initParamMap();
	}

	private void initParamMap() {
		int position = 1;
		if (nativeQuery.getParameterList() != null) {
			for (ParameterMapping param : nativeQuery.getParameterList()) {
				param.position = position;
				paramMap.put(position++, param);
			}
		}
	}

	private List getResultSet (Settings settings)
	{
		JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
		JDBCConnection jdbcConnection = jdbcServer.jdbcConnection();
		Connection connection = jdbcConnection.getConnection();
		PreparedStatement statement = null;
		List result = ListUtil.list();

		try {
			statement = connection.prepareStatement(sqlQuery);
			setPositionalParameters(settings);

			ResultSet rs = statement.executeQuery();

			ResultSetMetaData rsmd = rs.getMetaData();
			int NumOfCol = rsmd.getColumnCount();

			List columnLabels = new ArrayList<>(NumOfCol);
			for(int i = 1; i <= NumOfCol; i++) {
				columnLabels.add(rsmd.getColumnLabel(i));
			}
			setColumns(columnLabels);

			while (rs.next()) {
				Object[] row = new Object[NumOfCol];
				for (int i = 1; i <= NumOfCol; i++) {
					row[i - 1] = rs.getObject(i);
				}
				result.add(row);
			}
			rs.close();
		} catch (SQLException se) {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(se);
		} finally {
			try {
				jdbcConnection.release();
				connection.close();
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	private List<ParameterMapping> autoDiscover(Connection connection) throws SQLException
	{
		// Replace consecutive spaces with a single space
		String selectColumnQuery = sqlQuery.trim().replaceAll("\\s+", " ").toUpperCase();

		// Remove the values portion
		selectColumnQuery = selectColumnQuery.substring(0, selectColumnQuery.indexOf("VALUES"));

		// Check if we need all columns are only some of them
		String columns = "*";
		if(selectColumnQuery.contains("(") && selectColumnQuery.contains(")")) {
			columns = selectColumnQuery.substring(selectColumnQuery.indexOf("(")+1,selectColumnQuery.indexOf(")"));
		}
		selectColumnQuery = selectColumnQuery.replace("INSERT INTO ", "SELECT " + columns + " FROM ");
		if(selectColumnQuery.contains("(")) {
			selectColumnQuery = selectColumnQuery.substring(0, selectColumnQuery.indexOf("("));
		}
		System.out.println("Select query: " + selectColumnQuery);

		PreparedStatement ps = connection.prepareStatement(selectColumnQuery);
		ResultSetMetaData rsmd = ps.getMetaData();

		List<ParameterMapping> list = new ArrayList<>(rsmd.getColumnCount());
		for(int i = 0; i < rsmd.getColumnCount(); i++) {
			ParameterMapping pm = new ParameterMapping();
			pm.setType(new Integer(rsmd.getColumnType(i+1)).toString());
			pm.setName(rsmd.getColumnName(i+1));
			list.add(pm);
		}

		return list;
	}

	private void setPositionalParameters(Settings settings) {
		if(positionalParameters != null) {
			for(Map.Entry<Integer, Object> entry: positionalParameters.entrySet()) {
				if(!paramMap.containsKey(entry.getKey())) {
					throw new RuntimeException("Unable to find parameterList with key: " + entry.getKey());
				}
				// Note JDBC positional parameters start from 1
				ParameterMapping pm = paramMap.get(entry.getKey());

				int timestampType = Integer.parseInt(pm.type);
				if(timestampType == Types.TIMESTAMP || timestampType == Types.TIMESTAMP_WITH_TIMEZONE) {
					pm.setDateFormat(settings.getDateFormat());
				}
				pm.setValue(statement, entry.getValue());
			}
		}
	}

	private int executeUpdate (Settings settings)
	{
		// Check if batching is enabled
		NativeQuery nq = settings.getView().getNativeQuery();

		int result = 0;
		AMLBatchContext context = (AMLBatchContext)settings.getSessionContext();
		try {
			if(statement == null) {
				JDBCServer jdbcServer = Base.getService().getTransactionalJDBCServerForSession();
				jdbcConnection = jdbcServer.jdbcConnection();
				connection = jdbcConnection.getConnection();
				statement = connection.prepareStatement(sqlQuery);
				if(context != null) {
					context.setQuery(this);
				}

				// We will try to auto discover the types of the columns being inserted
				if(nq.getParameterList() == null && settings.getAction() == AggregateAction.CREATE) {
					nq.setParameterList(autoDiscover(connection));
					initParamMap();
				}
			}
			setPositionalParameters(settings);

			if (context != null) {
				if(context.isShouldBatch()) {
					statement.addBatch();
				} else {
					statement.executeBatch();
					context.setQuery(null);
				}
			} else {
				result = statement.executeUpdate();
			}
		} catch (SQLException se) {
			try {

				if(context == null || !context.isShouldBatch()) {
					jdbcConnection.release();
					connection.close();
				}
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			throw new RuntimeException(se);
		} finally {
			try {
				if(context == null || !context.isShouldBatch()) {
					jdbcConnection.release();
					connection.close();
				}
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		return result;
	}

	private boolean isSQL() {
		return sqlQuery != null;
	}

	private void prepare() {
		if(positionalParameters != null && namedParameters != null) {
			throw new RuntimeException("Either use positional or named parameters but not both");
		}
		if(namedParameters != null) {
			aqlOptions.setActualParameters(namedParameters);
		}
		if(positionalParameters != null) {
			List paramList = new ArrayList<>(positionalParameters.values());
			aqlOptions.setActualParameters(paramList);
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getResultList (View view, Settings settings)
	{
		List result = ListUtil.list();

		if (!isSQL())
		{
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);

			if (results.getErrors() != null) {
				throw new RuntimeException(results.getFirstError().toString());
			}
			else {
				while (results.next()) {
					result.add(results.getCurrent());
				}
			}
		}
		else {
			result = getResultSet(settings);
		}

		return result;
	}

	@Override
	public Object getSingleResult (View view, Settings settings)
	{
		if (!isSQL()) {
			prepare();
			AQLResultCollection results = Base.getService().executeQuery(aqlQuery, aqlOptions);
			return results.getSingleObject();
		}
		else {
			// Note: the first row is the column label
			List result = getResultSet(settings);
			if (result.size() == 0) {
				return null;
			}
			if (result.size() > 1) {
				throw new RuntimeException("Has more than 1 result");
			}
			else {
				result.get(0);
			}
		}

		return null;
	}

	@Override
	public void setParameter(String name, Object value) {

		boolean isPositional = false;
		if(StringUtils.isNumeric(name)) {
			isPositional = true;
		}

		if(isPositional) {
			if (positionalParameters == null) {
				// Sort the parameters by its position
				positionalParameters = new TreeMap<>();
			}

			int position = Integer.valueOf(name);
			positionalParameters.put(position, value);

		} else {
			if (namedParameters == null) {
				namedParameters = new HashMap<>();
			}

			namedParameters.put(name, value);
		}
	}

	@Override
	public boolean hasParameter(String name) {
		return namedParameters != null && namedParameters.containsKey(name);
	}

	@Override public Object execute (Settings settings)
	{
		if(settings.getAction() != AggregateAction.READ) {
			return executeUpdate(settings);

		} else {
			return getResultList(null, settings);
		}
	}

	@Override
	public void setMaxResults(int limit) {
		aqlOptions.setRowLimit(limit);
	}

	@Override
	public void setFirstResult(int offset) {
		throw new UnsupportedOperationException("Offset is not supported, rather give " +
		" last unique key of rows retrieved ordered by this key.");
	}	
}

