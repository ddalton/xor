package com.sap.ariba.hana.base.aml;

import tools.xor.service.AbstractQueryCapability;

/**
 * Created by i844711 on 10/3/16.
 */
public class AMLQueryCapability extends AbstractQueryCapability
{
    @Override
    public String getSurrogateValueMechanism(String queryAlias, String idFragment) {
        return queryAlias;
    }
}
