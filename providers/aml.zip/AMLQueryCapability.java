package com.sap.ariba.hana.base.aml;

import tools.xor.service.AbstractQueryCapability;

public class AMLQueryCapability extends AbstractQueryCapability
{
    @Override
    public String getSurrogateValueMechanism(String queryAlias, String idFragment) {
        return queryAlias;
    }
}
