package com.sap.ariba.hana.aheap.base.aml;

import tools.xor.SimpleType;
import ariba.base.fields.Type;

public class AMLSimpleType extends SimpleType
{
    private Type type;

    public AMLSimpleType (Class<?> clazz, Type type)
    {
        super(clazz);

        this.type = type;
    }

    @Override public boolean isLOB ()
    {
        return type.isLob();
    }
}
