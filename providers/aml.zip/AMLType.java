package com.sap.ariba.hana.base.aml;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ariba.base.core.BaseObject;
import ariba.base.core.ClusterRoot;
import ariba.base.core.ClusterRootBase;
import ariba.base.meta.core.FieldMeta;
import ariba.base.meta.core.LookupKeyMeta;
import ariba.base.meta.server.ClassMetaDT;
import ariba.base.meta.server.FieldMetaDT;
import ariba.util.core.ArrayUtil;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import tools.xor.AbstractType;
import tools.xor.AccessType;
import tools.xor.EntityType;
import tools.xor.Property;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.util.ClassUtil;

public class AMLType extends AbstractType
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());	

	private ClassMetaDT       classMetaDT;
	private List<Type>        baseTypes;
	private AMLProperty       identifierProperty;
	private AMLProperty       versionProperty;

	private static final Map<String,Class> primitiveMap = new HashMap<String,Class>();

	static {
		primitiveMap.put("int", Integer.TYPE);
		primitiveMap.put("long", Long.TYPE);
		primitiveMap.put("double", Double.TYPE);
		primitiveMap.put("float", Float.TYPE);
		primitiveMap.put("bool", Boolean.TYPE);
		primitiveMap.put("char", Character.TYPE);
		primitiveMap.put("byte", Byte.TYPE);
		primitiveMap.put("void", Void.TYPE);
		primitiveMap.put("short", Short.TYPE);
	}

	private static final Set<String> readonlyProperties = new HashSet<String>();
	static {
		readonlyProperties.add(ClusterRoot.KeyPartitionNumber);
		readonlyProperties.add(ClusterRoot.KeyPurgeState);
	};

	public AMLType(ClassMetaDT classMetaDT) {
		super();		
		this.classMetaDT = classMetaDT;
		
		init();
	}

	@Override
	protected void initXorEntity() {
		super.initXorEntity();

		LookupKeyMeta lookupKeyMeta = classMetaDT.lookupKey();

		if(lookupKeyMeta != null) {
			String[] lookupKeyPaths = lookupKeyMeta.paths;
			if (!ArrayUtil.nullOrEmptyArray(lookupKeyPaths)) {
				setNaturalKey(lookupKeyPaths);
			}
			;
		}
	}

	@Override
	public List<Type> getEmbeddableTypes() {
		List<Type> result = new ArrayList<Type>();

		FieldMetaDT[] fields = classMetaDT.getFields(FieldMeta.Kind.NormalOrDerivedOrInstanceOrTemplate);
		for (int i = 0; i < fields.length; i++) {
			FieldMetaDT property = fields[i];
			if(property.getType() != null && property.getType().isBaseObjectOnly() &&
				!property.getType().isVector()) {
				AMLType type = new AMLType(property.classMeta());
				result.add(type);
			}
		}

		return result; 
	}

	@Override
	public String getName() {
		// The name is unique in the namespace because if is qualified by the package name
		return classMetaDT.getName();
	}

	/**
	 * The name used to identity this entity externally.
	 * @return
	 */
	@Override
	public String getEntityName() {
		return getName();
	}

	@Override
	public String getURI() {
		return null;
	}

	@Override
	public Class<?> getInstanceClass() {
		try {
			return Class.forName(classMetaDT.getType().getClassName());
		} catch (ClassNotFoundException e) {
			throw new ClassUtil().wrapRun(e);
		}
	}

	public String getSuperTypeClassName() {
		return classMetaDT.superClassName();
	}

	@Override
	public boolean isInstance(Object object) {
		return getInstanceClass().isAssignableFrom(object.getClass());
	}

	public void setProperty(AMLDAS dataAccessService) {
		if(properties == null) {
			// populate the properties for this type
			properties = new HashMap<String, Property>();

			FieldMetaDT[] fields = classMetaDT.getAllFields(FieldMeta.Kind.AllKinds);
			for (int i = 0; i < fields.length; i++) {
				FieldMetaDT fieldMetaDT = fields[i];

				// Skip extension fields for now as they have a different way of
				// implementing getters and setters. For example - FieldValue.get() etc...
				if(fieldMetaDT.isExtensionField()) {
					continue;
				}

				// TODO: How to handle properties that do not have the type set e.g., master-data fields
				if(fieldMetaDT.getType() == null) {
					continue;
				}

				logger.debug("[" + getName() + "] FieldMetaDT property name: " + fieldMetaDT.name() + ", type name: " + fieldMetaDT.getType().getClassName());

				Class<?> propertyTypeClass = null;
				try {
					propertyTypeClass = Class.forName(fieldMetaDT.getType().getClassName());
				} catch (ClassNotFoundException e) {
					if(primitiveMap.containsKey(fieldMetaDT.getType().getClassName())) {
						propertyTypeClass = primitiveMap.get(fieldMetaDT.getType().getClassName());
					} else {
						continue;
					}
				}
				if(propertyTypeClass == null) {
					continue;
				}

				Type propertyType = dataAccessService.getType(propertyTypeClass);
				AMLProperty property = new AMLProperty(fieldMetaDT, propertyType, this);
				if(property.isMany()) {
					property.setType(dataAccessService.getType(List.class));
				}

				if(readonlyProperties.contains(property.getName())) {
					property.setReadOnly(true);
				}

				property.init(dataAccessService);
				properties.put(property.getName(), property);

				FieldMetaDT idProperty = classMetaDT.getField(BaseObject.KeyBaseId);
				if(idProperty != null) {
					logger.debug("FieldMetaDT identifier attribute name: " + idProperty.name());
					identifierProperty = (AMLProperty) properties.get(idProperty.name());
				}

				FieldMetaDT verProperty = classMetaDT.getField(ClusterRoot.KeyVersion);
				if(verProperty != null) {
					logger.debug("FieldMetaDT version attribute name: " + verProperty.name());
					versionProperty = (AMLProperty) properties.get(verProperty.name());
				}
			}
		}
	}

	public void setOpposite(AMLDAS dataAccessService) {
		for(Property property: properties.values()) {
			((AMLProperty)property).initMappedBy(dataAccessService);
		}
	}

	@Override
	public boolean isOpen() {
		// is this type backed by a concrete Java class, if not it is an open type
		try {
			Class.forName(classMetaDT.getType().getClassName());
		} catch (ClassNotFoundException e) {
			return true;
		}

		return false;
	}

	@Override
	public boolean isSequenced() {
		return false;
	}

	@Override
	public boolean isAbstract() {
		return false;
	}

	@Override
	public List<Type> getBaseTypes() {
		return baseTypes;
	}

	public void setBaseType(List<Type> types) {
		baseTypes = types;
	}

	@Override
	public List<Property> getDeclaredProperties() {
		List<Property> result = new ArrayList<Property>();

		if(classMetaDT.isClusterRoot() &&
			!classMetaDT.getType().isVector()) {

			FieldMetaDT[] fields = classMetaDT.getFields(FieldMeta.Kind.NormalOrDerivedOrInstanceOrTemplate);
			for (int i = 0; i < fields.length; i++) {
				FieldMetaDT declaredProperty = fields[i];
				logger.debug("[" + getName() + "] AMLType declared property name: " + declaredProperty.name());
				result.add(properties.get(declaredProperty.name()));
			}
		}

		return result;
	}

	@Override
	public List<?> getAliasNames() {
		return new ArrayList<String>();
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}

	@Override public AccessType getAccessType ()
	{
		// AML supports only PROPERTY access as it manager fields using an array
		// and this can change
		return AccessType.PROPERTY;
	}

	@Override
	public Property getIdentifierProperty() {
		return identifierProperty;
	}

	@Override
	public boolean isEmbedded() {
		return classMetaDT.getType().isBaseObjectOnly();
	}
	
	@Override
	public boolean isEntity() {
		return classMetaDT.getType().isClusterRoot();
	}		

	@Override
	public Property getVersionProperty() {
		return versionProperty;
	}

	@Override
	public boolean supportsDynamicUpdate() {
		return true;
	}

	@Override
	public void initRootEntityType (DataAccessService das)
	{
		Class<?> rootEntityClass = getInstanceClass();

		Class<?> parentClass = rootEntityClass.getSuperclass();
		while (parentClass != null) {
			if (ClusterRoot.class.isAssignableFrom(parentClass)) {
				if(das.getType(parentClass) instanceof EntityType) {
					rootEntityClass = parentClass;
				}
			}
			parentClass = parentClass.getSuperclass();
		}

		rootEntityType = (EntityType) das.getType(rootEntityClass);
	}

}

