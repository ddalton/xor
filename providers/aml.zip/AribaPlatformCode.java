package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseService;
import ariba.base.core.BaseSession;
import ariba.base.core.Partition;
import ariba.base.core.PartitionRuntime;
import ariba.base.fields.Realm;
import ariba.base.meta.server.CommunityUtil;
import ariba.base.server.BaseServer;
import ariba.base.server.ObjectServerSession;
import ariba.util.core.Fmt;
import test.ariba.framework.FrameworkUtil;

public abstract class AribaPlatformCode {
    private String realm;
    private Object result;
    private boolean doCommit;
    private boolean isPrivileged;
    private Boolean successfullyCommitted;

    public AribaPlatformCode(String realm) {
        this(realm, false, false);
    }

    public AribaPlatformCode(String realm, boolean doCommit) {
        this(realm, doCommit, false);
    }

    public AribaPlatformCode(String realm, boolean doCommit, boolean isPrivileged)
    {
        this.realm = realm;
        this.doCommit = doCommit;
        this.isPrivileged = isPrivileged;
    }

    public abstract void doWork();

    public Object getResult() {
        return this.result;
    }

    public void setResult(Object obj) {
        this.result = obj;
    }

    public boolean wasSuccessfullyCommitted() {
        return successfullyCommitted != null && successfullyCommitted;
    }

    public void execute ()
    {
        successfullyCommitted = null;

        BaseSession oldSession = null;
        BaseSession newSession = null;
        try {
            BaseServer.baseServer().convertThread("basePlatformThread");
            oldSession = Base.getSession();

            if (isPrivileged) {
                newSession = new ObjectServerSession(
                    BaseSession.SessionTypeDefault,
                    Realm.System);
                // This allows us to query across realms
                ((ObjectServerSession)newSession).setPrivileged(true);
            }
            else {
                Partition partition = getPartition(realm);
                newSession = Base.getService().createSideSession(partition, true);
                newSession.setPartition(partition);
            }
            Base.setSession(newSession);

            doWork();

            if (doCommit) {
                newSession.transactionCommit();
                successfullyCommitted = true;
            }
        }
        catch (Exception e) {
            if (doCommit) {
                successfullyCommitted = false;
            }
            e.printStackTrace();
        } finally {
            newSession.transactionRollback();

            // Restore the old session
            Base.setSession(null);
            if (oldSession != null) {
                Base.setSession(oldSession);
            }
        }
    }

    public static Partition getPartition(String partitionName) {
        BaseService service = Base.getService();
        PartitionRuntime runtime = service.getPartitionRuntime();
        //for(Partition p: runtime.getAllPartitions()) {
        //    System.out.println("****** PNAME: " + p.getName());
        //}
        Partition p = service != null?service.getPartition(partitionName):null;
        if(CommunityUtil.communityFilteringEnabled() && (p == null || !runtime.isActivePartition(p))) {
            String msg = Fmt.S(
                "%s. Skip the test because %s doesn\'t exist",
                "CommunityFiltering is enabled",
                partitionName);
            FrameworkUtil.skip(msg);
        }

        return p;
    }
}
