package com.sap.ariba.hana.aheap.base.aml;

import ariba.base.core.Base;
import ariba.base.core.BaseService;
import ariba.base.core.BaseSession;
import ariba.base.core.Partition;
import ariba.base.core.PartitionRuntime;
import ariba.base.meta.server.CommunityUtil;
import ariba.base.server.BaseServer;
import ariba.util.core.Fmt;
import test.ariba.framework.FrameworkUtil;

public abstract class AribaPlatformCode {
    private String realm;
    private Object result;
    private boolean doCommit;

    public AribaPlatformCode(String realm) {
        this.realm = realm;
    }

    public AribaPlatformCode(String realm, boolean doCommit) {
        this(realm);
        this.doCommit = doCommit;
    }

    public abstract void doWork();

    public Object getResult() {
        return this.result;
    }

    public void setResult(Object obj) {
        this.result = obj;
    }

    public void execute() {
        // Setup the correct realm
        BaseServer.baseServer().convertThread("schoolCornellThread");
        BaseSession oldSession = Base.getSession();
        Partition pYale = getPartition(realm);
        BaseSession session = Base.getService().createSideSession(pYale, true);
        session.setPartition(pYale);

        try {
            doWork();

            if(doCommit) {
                session.transactionCommit();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            session.transactionRollback();

            // untie any tied connection
            BaseServer.baseServer().getJDBCServer().untieConnection();

            // Restore the old session
            Base.setSession(null);
            if (oldSession != null) {
                Base.setSession(oldSession);
            }
        }
    }

    public static Partition getPartition(String partitionName) {
        BaseService service = Base.getService();
        PartitionRuntime runtime = service.getPartitionRuntime();
        //for(Partition p: runtime.getAllPartitions()) {
        //    System.out.println("****** PNAME: " + p.getName());
        //}
        Partition p = service != null?service.getPartition(partitionName):null;
        if(CommunityUtil.communityFilteringEnabled() && (p == null || !runtime.isActivePartition(p))) {
            String msg = Fmt.S(
                "%s. Skip the test because %s doesn\'t exist",
                "CommunityFiltering is enabled",
                partitionName);
            FrameworkUtil.skip(msg);
        }

        return p;
    }
}
