/**
 * XOR, empowering Model Driven Architecture in J2EE applications
 *
 * Copyright (c) 2012, Dilip Dalton
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations 
 * under the License.
 */

package tools.xor.providers.eo;

import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOModelGroup;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.eocontrol.EOKeyGlobalID;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSTimestamp;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import tools.xor.FilterType;
import tools.xor.ModelConstraint;
import tools.xor.MutableJsonProperty;
import tools.xor.MutableJsonTypeMapper;
import tools.xor.Property;
import tools.xor.Settings;
import tools.xor.Type;
import tools.xor.TypeMapper;
import tools.xor.service.AbstractDataAccessService;
import tools.xor.service.DASFactory;
import tools.xor.service.PersistenceOrchestrator;
import tools.xor.service.Shape;
import tools.xor.util.PersistenceType;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class is part of the Data Access Service framework
 *
 * @author Dilip Dalton
 */
public class EODAS extends AbstractDataAccessService
{

    private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());

    private List<ModelConstraint> constraints;

    public EODAS (TypeMapper typeMapper, String name, DASFactory dasFactory)
    {
        super(dasFactory);
        this.typeMapper = typeMapper;

        registerConverters();

        // Register types that should be left as is and not be treated as an entity
        MutableJsonTypeMapper.addUnchanged(EOGlobalID.class);
        MutableJsonTypeMapper.addUnchanged(NSTimestamp.class);
        //MutableJsonTypeMapper.addUnchanged(BaseVector.class);
    }

    private void registerConverters ()
    {
        MutableJsonProperty.registerConverter(EOGlobalID.class, getGlobalIdConverter());

        MutableJsonProperty.Converter dateConverter = MutableJsonProperty.findConverter(java.util.Date.class);
        if (dateConverter != null) {
            MutableJsonProperty.registerConverter(NSTimestamp.class, new NSTimestampConverter(dateConverter));
        }

        MutableJsonProperty.registerConverter(NSArray.class, getNSArrayConverter());
    }

    public class NSTimestampConverter extends MutableJsonProperty.AbstractConverter {

        private MutableJsonProperty.Converter dateConverter;

        public NSTimestampConverter(MutableJsonProperty.Converter dateConverter) {
            this.dateConverter = dateConverter;
        }

        @Override public Object toDomain (Settings settings,
                                          JSONObject jsonObject,
                                          Property property,
                                          String key) throws
            JSONException
        {
            Date date = (Date)dateConverter.toDomain(settings, jsonObject, property, key);
            if (date != null) {
                return new NSTimestamp(date.getTime());
            } else {
                return null;
            }
        }

        @Override public void add (Settings settings, JSONArray jsonArray, Object object)
        {
            this.dateConverter.add(settings, jsonArray, object);
        }
    }

    private MutableJsonProperty.Converter getGlobalIdConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof EOGlobalID)
                        return value;
                    else {
                        String bidString = jsonObject.getString(key).trim();
                        if(bidString != null && !"".equals(bidString)) {
                            Object[] values = new Object[] { jsonObject.getString(key)};
                            return EOKeyGlobalID.globalIDWithEntityName(property.getName(), values);
                        }
                    }
                }
                return null;
            }

            private String getKeyValue(Object object) {
                Object value = null;

                if(object instanceof EOKeyGlobalID) {
                    EOKeyGlobalID globalID = (EOKeyGlobalID) object;
                    value = globalID.keyValues()[0];
                }
                return value == null ? null : value.toString();
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(getKeyValue(object));
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, getKeyValue(object));
            }
        };

        return c;
    }

    private MutableJsonProperty.Converter getNSArrayConverter() {
        MutableJsonProperty.Converter c = new MutableJsonProperty.AbstractConverter() {

            @Override
            public Object toDomain(Settings settings, JSONObject jsonObject, Property property, String key) throws JSONException
            {
                if(jsonObject.has(key)) {
                    Object value = jsonObject.get(key);
                    if(value instanceof NSArray)
                        return value;
                    else {
                        // BaseVector methods take in a List instance
                        return new ArrayList();
                    }
                }
                return null;
            }

            @Override
            public void add(Settings settings, JSONArray jsonArray, Object object) {
                jsonArray.put(object);
            }

            @Override
            public void setExternal(Settings settings, JSONObject jsonObject, String name, Object object) throws JSONException {
                jsonObject.put(name, new JSONArray());
            }
        };

        return c;
    }

    public void setConstraints(List<ModelConstraint> value) {
        this.constraints = value;
    }

    @Override
    public void addShape(String name)
    {
        Shape shape = getOrCreateShape(name);

        logger.info("Getting the list of EO mapped classes");
        for (EOEntity eoEntity : getEntities(shape)) {
            logger.debug("     Adding EO persisted class: " + eoEntity.name());
            defineTypes(eoEntity, shape);
        }

        // Set the super type
        defineSuperType(shape);

        // Set the base types
        setBaseTypes(shape);

        // Define the properties for the Types
        // This will end up defining the simple types
        defineProperties(shape);

        postProcess(shape);
    }

    private Set<EOEntity> getEntities (Shape shape) {
        Set<EOEntity> result = new HashSet<EOEntity>();
        for(EOModel model: EOModelGroup.defaultGroup().models()) {
            result.addAll(model.entities());
        }

        return result;
    }

    private void populateFilter(Set<String> whitelist, Set<String> blacklist) {
        if(constraints != null) {
            for (ModelConstraint mc : constraints) {
                if (mc.getFilterType() == FilterType.BLACKLIST) {
                    blacklist.add(mc.getPath());
                }
                else {
                    whitelist.add(mc.getPath());
                }
            }
        }
    }

    protected void defineTypes (EOEntity eoEntity, Shape shape)
    {
        EOType dataType = new EOType(eoEntity);
        logger.debug("Defined data type: " + dataType.getName());
        shape.addType(eoEntity.className(), dataType);

        for (Type type : dataType.getEmbeddableTypes()) {
            shape.addType(type.getName(), type);
        }
    }

    protected void defineProperties (Shape shape)
    {
        for (Type type : shape.getUniqueTypes()) {
            if (!type.isOpen() && EOType.class.isAssignableFrom(type.getClass())) {
                EOType aMLType = (EOType) type;
                aMLType.setProperty(this, shape);
            }
        }

        // Link the bi-directional relationship between the properties
        for(Type type: shape.getUniqueTypes()) {
            if(EOType.class.isAssignableFrom(type.getClass())) {
                EOType eoType = (EOType) type;
                eoType.setOpposite(this);
            }
        }
    }

    // TODO: How is this different from setSuperType?
    // For now we use the supertype as the base type
    protected void setBaseTypes (Shape shape)
    {
        for (Type type : shape.getUniqueTypes()) {
            if (EOType.class.isAssignableFrom(type.getClass())) {

                EOType aMLType = (EOType) type;

                if (aMLType.isEmbedded())
                    continue;

                List<Type> baseTypes = new ArrayList<Type>();
                if(aMLType.getSuperType() != null) {
                    baseTypes.add(aMLType.getSuperType());
                }
                aMLType.setBaseType(baseTypes);
            }
        }
    }

    @Override
    public PersistenceType getAccessType ()
    {
        return PersistenceType.EOF;
    }

    @Override public PersistenceOrchestrator createPO (Object sessionContext, Object data)
    {
        return new EOPersistenceOrchestrator();
    }

}
