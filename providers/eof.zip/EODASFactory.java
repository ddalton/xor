/**
 * XOR, empowering Model Driven Architecture in J2EE applications
 *
 * Copyright (c) 2012, Dilip Dalton
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 * See the License for the specific language governing permissions and limitations 
 * under the License.
 */

package tools.xor.providers.eo;

import tools.xor.ModelConstraint;
import tools.xor.TypeMapper;
import tools.xor.service.AbstractDASFactory;
import tools.xor.service.AbstractDataAccessService;
import tools.xor.service.HibernateDAS;
import tools.xor.service.JPADAS;

import java.util.ArrayList;
import java.util.List;

public class EODASFactory extends AbstractDASFactory
{
	List<ModelConstraint> modelConstraints;

	public EODASFactory(String name, List<ModelConstraint> constraints) {
		this.name = name;
		this.modelConstraints = constraints;
	}

	public EODASFactory() {
	}

	@Override
	public void injectDependencies(Object bean, String name) {
		// Dependency injection is not supported in the default case
		// The resources need to be manually or statically configured
	}

	@Override
	protected HibernateDAS createHibernateDAS(TypeMapper typeMapper) {
		throw new UnsupportedOperationException("Hibernate configuration is not supported");
	}

	@Override
	protected JPADAS createJPADAS(TypeMapper typeMapper, String name) {
		throw new UnsupportedOperationException("JPA configuration is not supported");
	}

	@Override
	protected AbstractDataAccessService createCustomDAS(TypeMapper typeMapper, String name) {
		EODAS result = new EODAS(typeMapper, name, this);
		result.setConstraints(modelConstraints);

		return result;
	}
}
