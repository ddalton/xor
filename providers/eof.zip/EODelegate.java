package tools.xor.providers.eo;

import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOFetchSpecification;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.foundation.NSArray;

public class EODelegate
{
    /*
    @Override public boolean editingContextShouldPresentException (EOEditingContext eoEditingContext,
                                                                   Throwable throwable)
    {
        return true;
    }*/

    public boolean editingContextShouldValidateChanges (EOEditingContext eoEditingContext)
    {
        return false;
    }

    /*
    @Override public void editingContextWillSaveChanges (EOEditingContext eoEditingContext)
    {

    }

    @Override public boolean editingContextShouldInvalidateObject (EOEditingContext eoEditingContext,
                                                                   EOEnterpriseObject eoEnterpriseObject,
                                                                   EOGlobalID eoGlobalID)
    {
        return true;
    }

    @Override public boolean editingContextShouldUndoUserActionsAfterFailure (EOEditingContext eoEditingContext)
    {
        return false;
    }

    @Override public NSArray editingContextShouldFetchObjects (EOEditingContext eoEditingContext,
                                                               EOFetchSpecification eoFetchSpecification)
    {
        return eoEditingContext.objectsWithFetchSpecification(eoFetchSpecification, eoEditingContext);
    }

    @Override public boolean editingContextShouldMergeChangesForObject (EOEditingContext eoEditingContext,
                                                                        EOEnterpriseObject eoEnterpriseObject)
    {
        return true;
    }

    @Override public void editingContextDidMergeChanges (EOEditingContext eoEditingContext)
    {

    }*/
}
