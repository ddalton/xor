package tools.xor.providers.eo;

import tools.xor.util.ExcelJsonCreationStrategy;
import tools.xor.util.ObjectCreator;

public class EOJsonCreationStrategy extends ExcelJsonCreationStrategy
{
    public EOJsonCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    protected void setDomainCreationStrategy(ObjectCreator objectCreator) {
        pojoCS = new EOPOJOCreationStrategy(objectCreator);
    }
}


