package tools.xor.providers.eo;

import tools.xor.ExcelJsonTypeMapper;
import tools.xor.TypeMapper;
import tools.xor.util.CreationStrategy;
import tools.xor.util.ObjectCreator;

public class EOJsonTypeMapper extends ExcelJsonTypeMapper
{
    @Override
    protected TypeMapper createInstance() {
        return new EOJsonTypeMapper();
    }

    @Override
    public CreationStrategy getCreationStrategy(ObjectCreator oc) {
        return new EOJsonCreationStrategy(oc);
    }
}
