package tools.xor.providers.eo;

import com.webobjects.eocontrol.EOEnterpriseObject;
import tools.xor.BasicType;
import tools.xor.BusinessObject;
import tools.xor.Property;
import tools.xor.util.ClassUtil;
import tools.xor.util.ObjectCreator;
import tools.xor.util.POJOCreationStrategy;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;

public class EOPOJOCreationStrategy extends POJOCreationStrategy
{
    public EOPOJOCreationStrategy(ObjectCreator objectCreator) {
        super(objectCreator);
    }

    @Override
    public Object newInstance(Object from, BasicType type, Class<?> toClass, BusinessObject container,
                              Property containmentProperty) throws Exception {

        if(type != null && !EOEnterpriseObject.class.isAssignableFrom(ClassUtil.getUnEnhanced(type.getInstanceClass())) && type.isDataType()) {
            // Handle simple types like String etc...
            return type.newInstance(from);
        }

        // If toClass is null then fallback to type
        Class<?> instanceClass = (toClass == null) ? ClassUtil.getUnEnhanced(type.getInstanceClass()) : toClass;

        if( (toClass != null && EOEnterpriseObject.class.isAssignableFrom(toClass)) ||
            (toClass == null && type != null && EOEnterpriseObject.class.isAssignableFrom(ClassUtil.getUnEnhanced(type.getInstanceClass()))) ) {
            Constructor<?> constructor = instanceClass.getConstructor();

            if (constructor != null) {
                if(Modifier.isAbstract(instanceClass.getModifiers())) {
                    return null;
                }

                Object result = constructor.newInstance();
                EOPersistenceOrchestrator po = (EOPersistenceOrchestrator)getObjectCreator().getPersistenceOrchestrator();
                po.eoEditingContext.insertObject((EOEnterpriseObject)result);

                return result;
            }
        }

        return ClassUtil.newInstance(instanceClass);
    }
}
