package tools.xor.providers.eo;

import com.webobjects.eoaccess.EOAdaptorChannel;
import com.webobjects.eoaccess.EODatabaseChannel;
import com.webobjects.eoaccess.EODatabaseContext;
import com.webobjects.eoaccess.EOModel;
import com.webobjects.eoaccess.EOObjectNotAvailableException;
import com.webobjects.eoaccess.EOUtilities;
import com.webobjects.eocontrol.EOCustomObject;
import com.webobjects.eocontrol.EOEditingContext;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOFetchSpecification;
import com.webobjects.eocontrol.EOGlobalID;
import com.webobjects.foundation.NSArray;
import com.webobjects.foundation.NSMutableDictionary;
import com.webobjects.jdbcadaptor.JDBCChannel;
import com.webobjects.jdbcadaptor.JDBCContext;
import tools.xor.BusinessObject;
import tools.xor.EntityType;
import tools.xor.Type;
import tools.xor.service.AbstractPersistenceOrchestrator;
import tools.xor.service.QueryCapability;
import tools.xor.util.ClassUtil;
import tools.xor.view.AggregateView;
import tools.xor.view.Query;
import tools.xor.view.StoredProcedure;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class EOPersistenceOrchestrator
	extends AbstractPersistenceOrchestrator
{
	// This is needed only for the database connection
	EOModel eoModel;

	// This needs to be set by the client first
	EOEditingContext eoEditingContext;

	public void setEoEditingContext (EOEditingContext eoEditingContext)
	{
		this.eoEditingContext = eoEditingContext;
	}

	public void setEoModel (EOModel eoModel)
	{
		this.eoModel = eoModel;
	}

	/**
	 * Save the entity in the persistence store
	 * 
	 * @param entity
	 * @return
	 */
	@Override
	public void saveOrUpdate(Object entity) {

		if(entity instanceof EOEnterpriseObject) {
			eoEditingContext.insertObject((EOEnterpriseObject)entity);
		}
	}

	@Override protected void createStatement (StoredProcedure sp)
	{
		// TODO: EOStoredProcedure
		try {
			EODatabaseContext eodatabasecontext = EODatabaseContext.registeredDatabaseContextForModel(
				eoModel,
				eoEditingContext);
			EODatabaseChannel eodatabasechannel = eodatabasecontext.availableChannel();
			EOAdaptorChannel eoadaptorchannel = eodatabasechannel.adaptorChannel();

			if(eoadaptorchannel instanceof JDBCChannel) {
				JDBCChannel jdbcChannel = (JDBCChannel) eoadaptorchannel;

				Connection connection = ((JDBCContext)jdbcChannel.adaptorContext()).connection();
				DatabaseMetaData dbmd = connection.getMetaData();
				if (!dbmd.supportsStoredProcedures()) {
					throw new UnsupportedOperationException(
						"Stored procedures with JDBC escape syntax is not supported");
				}

				if (sp.isImplicit()) {
					sp.setStatement(connection.createStatement());
				}
				else {
					sp.setStatement(connection.prepareCall(sp.jdbcCallString()));
				}
			}
		} catch (SQLException e) {
			throw ClassUtil.wrapRun(e);
		}
	}

	@Override
	public void clear() {
		eoEditingContext.invalidateAllObjects();
	}

	@Override
	public void clear(Set<Object> ids) {
		for(Object id: ids) {
			EOEnterpriseObject obj = eoEditingContext.objectForGlobalID((EOGlobalID)id);
			eoEditingContext.forgetObject(obj);
		}
	}
	
	@Override 
	public void refresh(Object object) {
		eoEditingContext.refreshObject((EOEnterpriseObject)object);
	}

	/**
	 * Delete the entity from the persistence store
	 * 
	 * @param entity
	 */
	@Override
	public void delete(Object entity) {
		eoEditingContext.deleteObject((EOEnterpriseObject)entity);
	}

	@Override
	public void flush() {
		eoEditingContext.saveChanges();
	}

	/**
	 * Flushing is explicitly performed and so this is not relevant.
	 *
	 * @return
	 */
	@Override
	public Object disableAutoFlush() {
		return null;
	}

	@Override
	public void setFlushMode(Object flushMode) {
		throw new UnsupportedOperationException();
	}

	@Override
	protected boolean isTransient(BusinessObject from) {
		Object instance = ClassUtil.getInstance(from);

		if(instance instanceof EOCustomObject) {
			EOCustomObject eoCustomObject = (EOCustomObject) instance;
			EOGlobalID id = eoCustomObject.__globalID();
			return id.isTemporary();
		}

		return false;
	}

	@Override
	public Object findById(Class<?> persistentClass, Object id) {
		try {
			return EOUtilities.objectWithPrimaryKeyValue(
                eoEditingContext,
                persistentClass.getName(),
                id);
		}
		catch (EOObjectNotAvailableException e) {
			return null;
		}
	}

	@Override public List<Object> findByIds (EntityType entityType, Collection ids)
	{
		if (ids != null && ids.size() > 0) {

			String idName = entityType.getIdentifierProperty().getName();

			InQualifier in = new InQualifier(
				EOUtilities.entityNamed(eoEditingContext, entityType.getName()),
				idName, ids.toArray(new Object[ids.size()]));
			EOFetchSpecification fs = new EOFetchSpecification(entityType.getName(), in, null);
			return eoEditingContext.objectsWithFetchSpecification(fs);
		}
		return null;
	}

	private NSMutableDictionary getDictionary(Map<String, Object> propertyValues) {
		NSMutableDictionary params = new NSMutableDictionary();
		for(Map.Entry<String, Object> entry: propertyValues.entrySet()) {
			params.setObjectForKey(entry.getValue(), entry.getKey());
		}

		return params;
	}

	private List<Object> getResult (Type type, Map<String, Object> propertyValues)
	{

		return EOUtilities.objectsMatchingValues(eoEditingContext, type.getName(), getDictionary(propertyValues));
	}
	
	@Override
	public Object findByProperty(Type type, Map<String, Object> propertyValues) {

		List results =  getResult(type, propertyValues);
		if(results.size() == 0) {
			return null;
		} else {
			return (EOEnterpriseObject)results.get(0);
		}
	}

	@Override public Object getCollection (Type type, Map<String, Object> collectionOwnerKey)
	{
		List<Object> resultList = getResult(type, collectionOwnerKey);
		Set<Object> result = new HashSet<Object>(resultList);
		return result;
	}

	@Override
	public QueryCapability getQueryCapability() {
		return new EOQueryCapability();
	}


	@Override
	public Object getCached(Class<?> persistentClass, Object id)
	{
		return eoEditingContext.objectForGlobalID((EOGlobalID)id);
	}

	@Override public Query getQuery (String s,
									 QueryType queryType,
									 StoredProcedure storedProcedure)
	{
		Query result = null;
		switch(queryType) {
		case OQL:
			// TODO: Fetch specification
			result = new EOQuery(s);
			break;

		case SQL:
			result = new EOQuery(s);
			break;

		case SP:
			throw new UnsupportedOperationException("Store procedure is not supported");

		default:
			throw new RuntimeException("Unsupported queryType: " + queryType.name());
		}

		return result;
	}

	@Override
	protected void performAttach(BusinessObject input, Object instance) {
		throw new UnsupportedOperationException("The entity type " + input.getType().getName()
			+ " does not support dynamic update");
	}
	
	@Override
	public boolean supportsStoredProcedure() {
		return false;
	}

	@Override public Blob createBlob ()
	{
		return null;
	}
}
