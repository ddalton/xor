package tools.xor.providers.eo;

import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eocontrol.EOCustomObject;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOKeyGlobalID;
import com.webobjects.foundation.NSKeyValueCoding;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import tools.xor.AbstractProperty;
import tools.xor.Property;
import tools.xor.StringType;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.service.Shape;
import tools.xor.util.ClassUtil;
import tools.xor.util.Constants;

import java.util.ArrayList;
import java.util.List;

public class EOProperty extends AbstractProperty
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());	

	private EOAttribute attribute;
	private EORelationship relationship;
	private Boolean     cascaded;

	public EOProperty(com.webobjects.eoaccess.EOProperty eoProperty, Type type, EOType parentType) {
		super(type, parentType);
		if(eoProperty instanceof EOAttribute) {
			attribute = (EOAttribute) eoProperty;
		} else {
			relationship = (EORelationship) eoProperty;
		}

		if(type instanceof StringType) {
			addConstraint(Constants.XOR.CONS_LENGTH, attribute.width());
		}

		init();		
	}

	private com.webobjects.eoaccess.EOProperty getProperty() {
		return (attribute != null) ? attribute : relationship;
	}

	public EOProperty (String itemList, Type type, EOType spType)
	{
		super(itemList, type, spType);
	}

	@Override
	public String getName() {
		if(!isOpenContent() || getProperty() != null) {
			return getProperty().name();
		} else {
			return this.name;
		}
	}

	@Override
	public boolean isMany() {
		if(!isOpenContent() && relationship != null) {
			return relationship.isToMany();
		} else {
			return false;
		}
	}

	@Override
	public boolean isContainment() {

		if(!isOpenContent() || relationship != null) {
			if(!relationship.ownsDestination()) {
				return false;
			}
		}

		return true;
	}

	@Override
	public Object getDefault() {
		return null;
	}

	@Override
	public boolean isReadOnly() {
		boolean result = false;

		result = attribute != null ? attribute.isReadOnly() : false;

		return result || super.isReadOnly();
	}

	@Override
	public boolean isNullable() {
		if(!isOpenContent() && getProperty() != null) {
			return attribute != null ? attribute.allowsNull() : !relationship.isMandatory();
		} else {
			return true;
		}
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}

	@Override
	public void init(DataAccessService das, Shape shape) {

		if(isMany()) { // Only Vector type is supported
			// The index is ColumnMetaDT.VectorIndexName which is of Integer type
			keyType = shape.getType(Integer.class);
			if(isMany()) {
				elementType = shape.getType(relationship.destinationEntity().className());
			}
		}
	}

	@Override
	public boolean isIdentifier() {

		return attribute != null && attribute.entity().primaryKeyAttributes().contains(attribute);
	}

	@Override public boolean isCollectionOfReferences ()
	{
		return false;
	}

	@Override public boolean isOpenContent ()
	{
		if(isIdentifier()) {
			return false;
		}

		boolean open = super.isOpenContent();

		if(!open) {
			// check FieldMetaDT to see if it is a derived property,
			// We consider derived as open properties
			if(attribute != null && attribute.isDerived()) {
				open = true;
			}
		}

		return open;
	}

	@Override
	protected void initByAnnotations() {
		// JPA annotations not supported in EO
	}

	@Override
	public String getMappedByName() {
		if (relationship != null) {
			EORelationship inverse = relationship.inverseRelationship();
			if(inverse != null) {
				return inverse.name();
			}
		}

		return null;
	}

	@Override
	public void initMappedBy(DataAccessService das) {
		// This is not supported in EO
		String mappedBy = getMappedByName();

		Type type = isMany() ? getElementType() : getType();
		setMappedBy( mappedBy != null ? type.getProperty(mappedBy) : null, mappedBy);

		if(getMappedBy() != null) {
			logger.debug("Opposite of property '" + getContainingType().getName() + "." + getName() + "' is '" + mappedBy + "'");
		}
	}

	@Override
	public boolean isMap() {
		// Only the List type is supported
		return false;
	}

	@Override
	public boolean isList() {
		if(isMany())
		{
			return true;
		}

		return false;
	}

	@Override
	public boolean isSet() {
		// Only the List type is supported
		return false;
	}

	@Override
	public Object query(Object dataObject) {

		Object instance = ClassUtil.getInstance(dataObject);

		try {
			if(isManaged() && instance instanceof EOEnterpriseObject) {
                if(isIdentifier() && instance instanceof EOCustomObject) {
                    if(((EOCustomObject)instance).__globalID() instanceof EOKeyGlobalID) {
                        return ((EOKeyGlobalID)((EOCustomObject)instance).__globalID()).keyValues()[0];
                    } else {
                        return null;
                    }
                }
                return ((EOEnterpriseObject)instance).valueForKey(getName());
            } else {
                return super.query(dataObject);
            }
		}
		catch (NSKeyValueCoding.UnknownKeyException e) {
			return null;
		}
	}

	@Override
	public void executeUpdate(Object dataObject, Object propertyValue) {
		try {
			Object instance = ClassUtil.getInstance(dataObject);
			propertyValue = ClassUtil.getInstance(propertyValue);
			if(isManaged() && instance instanceof EOEnterpriseObject) {
                ((EOEnterpriseObject)instance).takeValueForKey(propertyValue, getName());
            } else {
                super.executeUpdate(dataObject, propertyValue);
            }
		}
		catch (NSKeyValueCoding.UnknownKeyException e) {
			return;
		}
	}
}

