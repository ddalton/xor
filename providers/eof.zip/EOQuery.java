package tools.xor.providers.eo;

import com.webobjects.eocontrol.EOFetchSpecification;
import tools.xor.view.AbstractQuery;
import tools.xor.view.QueryView;

import java.util.ArrayList;
import java.util.List;

public class EOQuery extends AbstractQuery
{
	private String sqlQuery;
	private EOFetchSpecification eoFetchSpecification;

	private void initOptions()
	{
		eoFetchSpecification = new EOFetchSpecification();
	}

	public EOQuery(String sql) {
		initOptions();
		sqlQuery = sql;
	}

	private boolean isSQL() {
		return sqlQuery != null;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List getResultList (QueryView queryView)
	{
		// TODO: Handle fetch specification and refactor getQuery
		return new ArrayList();
	}

	@Override
	public Object getSingleResult (QueryView queryView)
	{
		return null;
	}

	@Override
	public void setParameter(String name, Object value) {
		throw new UnsupportedOperationException("Query parameters are not supported in AQL");
	}

	@Override
	public boolean hasParameter(String name) {
		throw new UnsupportedOperationException("Query parameters are not supported in AQL");
	}

	@Override
	public void setMaxResults(int limit) {
		eoFetchSpecification.setFetchLimit(limit);
	}

	@Override
	public void setFirstResult(int offset) {
		throw new UnsupportedOperationException("Offset is not supported, rather give " +
		" last unique key of rows retrieved ordered by this key.");
	}	
}

