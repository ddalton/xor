package tools.xor.providers.eo;

import tools.xor.service.AbstractQueryCapability;

public class EOQueryCapability extends AbstractQueryCapability
{
    @Override
    public String getSurrogateValueMechanism(String queryAlias, String idFragment) {
        return queryAlias;
    }
}
