package tools.xor.providers.eo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eocontrol.EOCustomObject;
import com.webobjects.eocontrol.EOEnterpriseObject;
import com.webobjects.eocontrol.EOGenericRecord;
import com.webobjects.foundation.NSArray;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import tools.xor.AbstractType;
import tools.xor.AccessType;
import tools.xor.EntityType;
import tools.xor.Property;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.util.ClassUtil;

public class EOType extends AbstractType
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());	

	private EOEntity    eoEntity;
	private List<Type>  baseTypes;
	private EOProperty  identifierProperty;
	private EOProperty  versionProperty;

	private static final Map<String,Class> primitiveMap = new HashMap<String,Class>();

	static {
		primitiveMap.put("int", Integer.TYPE);
		primitiveMap.put("long", Long.TYPE);
		primitiveMap.put("double", Double.TYPE);
		primitiveMap.put("float", Float.TYPE);
		primitiveMap.put("bool", Boolean.TYPE);
		primitiveMap.put("char", Character.TYPE);
		primitiveMap.put("byte", Byte.TYPE);
		primitiveMap.put("void", Void.TYPE);
		primitiveMap.put("short", Short.TYPE);
	}

	public EOType(EOEntity eoEntity) {
		super();		
		this.eoEntity = eoEntity;
		
		init();
	}

	@Override
	protected void initXorEntity() {
		super.initXorEntity();

		if(eoEntity.primaryKeyAttributes() != null) {
			String[] key = new String[eoEntity.primaryKeyAttributes().size()];
			for(int i = 0; i < eoEntity.primaryKeyAttributes().size(); i++) {
				com.webobjects.eoaccess.EOProperty p = eoEntity.primaryKeyAttributes().get(i);
				key[i] = p.name();
			}
			setNaturalKey(key);
		}
	}

	@Override
	public List<Type> getEmbeddableTypes() {
		return new ArrayList<Type>();
	}

	@Override
	public String getName() {
		// The name is unique in the namespace because if is qualified by the package name
		return eoEntity.name();
	}

	/**
	 * The name used to identity this entity externally.
	 * @return
	 */
	@Override
	public String getEntityName() {
		return getName();
	}

	@Override
	public String getURI() {
		return null;
	}

	@Override
	public Class<?> getInstanceClass() {
		try {
			return Class.forName(eoEntity.className());
		} catch (ClassNotFoundException e) {
			throw new ClassUtil().wrapRun(e);
		}
	}

	@Override
	public boolean isInstance(Object object) {
		return getInstanceClass().isAssignableFrom(object.getClass());
	}

	private EOProperty addProperty(EODAS dataAccessService, Class<?> propertyTypeClass, com.webobjects.eoaccess.EOProperty property) {
		Type propertyType = dataAccessService.getType(propertyTypeClass);
		EOProperty eoProperty = new EOProperty(property, propertyType, this);
		eoProperty.init(dataAccessService);
		properties.put(eoProperty.getName(), eoProperty);

		return eoProperty;
	}

	public void setProperty(EODAS dataAccessService) {
		if(properties == null) {
			// populate the properties for this type
			properties = new HashMap<String, Property>();

			// Simple attributes
			for(EOAttribute attribute: eoEntity.attributes()) {

				Class<?> propertyTypeClass = null;
				try {
					propertyTypeClass = Class.forName(attribute.className());
				} catch (ClassNotFoundException e) {
					if(primitiveMap.containsKey(attribute.className())) {
						propertyTypeClass = primitiveMap.get(attribute.className());
					} else {
						continue;
					}
				}
				if(propertyTypeClass == null) {
					continue;
				}

				addProperty(dataAccessService, propertyTypeClass, attribute);

				if(eoEntity.primaryKeyAttributeNames().size() == 1) {
					String idName = eoEntity.primaryKeyAttributeNames().get(0);
					if (idName != null) {
						logger.debug("Identifier attribute name: " + idName);
						identifierProperty = (EOProperty)properties.get(idName);
					}
				}

				// Optimistic locking is based on snapshots and not
				// on a version column, so versionProperty field is not
				// initialized
			}

			// Relationships
			for(EORelationship relationship: eoEntity.relationships()) {

				Class<?> propertyTypeClass = null;
				try {
					propertyTypeClass = Class.forName(relationship.destinationEntity().className());
				}
				catch (ClassNotFoundException e) {
					continue;
				}

				if(propertyTypeClass == null) {
					continue;
				}

				EOProperty eoProperty = addProperty(dataAccessService, propertyTypeClass, relationship);

				if(relationship.isToMany()) {
					eoProperty.setType(dataAccessService.getType(List.class));
				}
			}
		}
	}

	public void setOpposite(EODAS dataAccessService) {
		for(Property property: properties.values()) {
			((EOProperty)property).initMappedBy(dataAccessService);
		}
	}

	@Override
	public boolean isOpen() {
		// is this type backed by a concrete Java class, if not it is an open type
		try {
			Class.forName(eoEntity.className());
		} catch (ClassNotFoundException e) {
			return true;
		}

		return false;
	}

	@Override
	public boolean isSequenced() {
		return false;
	}

	@Override
	public boolean isAbstract() {
		return false;
	}

	@Override
	public List<Type> getBaseTypes() {
		return baseTypes;
	}

	public void setBaseType(List<Type> types) {
		baseTypes = types;
	}

	@Override
	public List<Property> getDeclaredProperties() {
		return new ArrayList(this.properties.values());
	}

	@Override
	public List<?> getAliasNames() {
		return new ArrayList<String>();
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}

	@Override public AccessType getAccessType ()
	{
		// EO supports only PROPERTY access as it manager fields using an array
		// and this can change
		return AccessType.PROPERTY;
	}

	@Override
	public Property getIdentifierProperty() {
		return identifierProperty;
	}

	@Override
	public boolean isEmbedded() {
		return false;
	}
	
	@Override
	public boolean isEntity() {
		return eoEntity.hasRealAttributes() && !eoEntity.isAbstractEntity();
	}		

	@Override
	public Property getVersionProperty() {
		return versionProperty;
	}

	@Override
	public boolean supportsDynamicUpdate() {
		return true;
	}

	@Override
	public void initRootEntityType (DataAccessService das)
	{
		Class<?> rootEntityClass = getInstanceClass();

		Class<?> parentClass = rootEntityClass.getSuperclass();
		while (parentClass != null) {
			if (EOEnterpriseObject.class.isAssignableFrom(parentClass)) {
				if(das.getType(parentClass) instanceof EntityType) {
					rootEntityClass = parentClass;
				}
			}
			parentClass = parentClass.getSuperclass();
		}

		rootEntityType = (EntityType) das.getType(rootEntityClass);
	}

}

