package tools.xor.providers.eo;

import com.webobjects.eoaccess.EOAttribute;
import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EOEntityIndex;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eocontrol.EOEnterpriseObject;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import tools.xor.AbstractProperty;
import tools.xor.AbstractType;
import tools.xor.AccessType;
import tools.xor.EntityType;
import tools.xor.ExtendedProperty;
import tools.xor.Property;
import tools.xor.Type;
import tools.xor.service.DataAccessService;
import tools.xor.service.Shape;
import tools.xor.util.ClassUtil;

import java.beans.Introspector;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EOType extends AbstractType
{
	private static final Logger logger = LogManager.getLogger(new Exception().getStackTrace()[0].getClassName());

	private static final String UNDERSCORE = "_";

	private EOEntity    eoEntity;
	private List<Type>  baseTypes;
	private EOProperty  identifierProperty;
	private EOProperty  versionProperty;

	private static final Map<String,Class> primitiveMap = new HashMap<String,Class>();

	static {
		primitiveMap.put("int", Integer.TYPE);
		primitiveMap.put("long", Long.TYPE);
		primitiveMap.put("double", Double.TYPE);
		primitiveMap.put("float", Float.TYPE);
		primitiveMap.put("bool", Boolean.TYPE);
		primitiveMap.put("char", Character.TYPE);
		primitiveMap.put("byte", Byte.TYPE);
		primitiveMap.put("void", Void.TYPE);
		primitiveMap.put("short", Short.TYPE);
	}

	public EOType(EOEntity eoEntity) {
		super();		
		this.eoEntity = eoEntity;
		
		init();
	}

	@Override
	public String getGetterPropertyName(Method m) {
		return m.getName();
	}

	@Override
	public String getSetterPropertyName(Method m) {
		return m.getName().substring(("set" + UNDERSCORE).length());
	}

	@Override
	protected String decapitalize(String propertyName) {
		if(propertyName.startsWith(UNDERSCORE)) {
			return propertyName.substring(UNDERSCORE.length());
		}
		return propertyName;
	}

	@Override
	protected boolean isGetterMethod(Class<?> beanClass, Method m) {
		boolean result = super.isGetterMethod(beanClass, m);

		// This will work only after properties has been populated
		if(!result && properties != null) {

			// We give preference to the internal getter method as they work with primitive
			// types
			if(m.getName().startsWith(UNDERSCORE)) {
				String name = m.getName().substring(UNDERSCORE.length());
				if (getProperty(name) != null) {
					return true;
				}
			}
		}

		return result;
	}

	@Override
	protected boolean isSetterMethod(Class<?> beanClass, Method m) {

		return m.getName().startsWith("set" + UNDERSCORE);
	}

	@Override
	public void initEnd(Shape shape) {
		// If we have an identifier property then search for the natural key from the indexes
		if(identifierProperty != null) {
			nextIndex:
			for (EOEntityIndex index : eoEntity.indexes()) {
				if (index.constraint() != null) {
					Object obj = index.constraint();
					if (obj.toString() == "Unique") {
						System.out.println("Found unique constraint");
						for (EOAttribute attr : index.attributes()) {
							ExtendedProperty prop = (ExtendedProperty)getProperty(attr.name());
							if (!prop.isDataType()) {
								continue nextIndex;
							}
						}

						// Index of simple attributes
						String[] key = new String[index.attributes().size()];
						for (int i = 0; i < index.attributes().size(); i++) {
							com.webobjects.eoaccess.EOProperty p = index.attributes().get(i);
							key[i] = p.name();
						}
						setNaturalKey(key);
					}
				}
			}
		} else {
			String[] key = new String[eoEntity.primaryKeyAttributes().size()];
			for (int i = 0; i < eoEntity.primaryKeyAttributes().size(); i++) {
				com.webobjects.eoaccess.EOProperty p = eoEntity.primaryKeyAttributes().get(i);
				key[i] = p.name();
			}
			setNaturalKey(key);
		}

		// Re-execute the getter collection, since it depends on the properties being initialized
		initGetterMethods();

		// Re-initialize the properties again
		if(properties != null) {
			for (Property property : properties.values()) {
				if(property instanceof AbstractProperty) {
					((AbstractProperty)property).init();
				}
			}
		}
	}

	@Override
	public List<Type> getEmbeddableTypes() {
		return new ArrayList<Type>();
	}

	@Override
	public String getName() {
		// The name is unique in the namespace because if is qualified by the package name
		return eoEntity.className();
	}

	/**
	 * The name used to identity this entity externally.
	 * @return
	 */
	@Override
	public String getEntityName() {
		return getName();
	}

	@Override
	public String getURI() {
		return null;
	}

	@Override
	public Class<?> getInstanceClass() {
		try {
			return Class.forName(eoEntity.className());
		} catch (ClassNotFoundException e) {
			throw new ClassUtil().wrapRun(e);
		}
	}

	@Override
	public boolean isInstance(Object object) {
		return getInstanceClass().isAssignableFrom(object.getClass());
	}

	private EOProperty addProperty(EODAS dataAccessService, Class<?> propertyTypeClass, com.webobjects.eoaccess.EOProperty property, Shape shape) {
		Type propertyType = shape.getType(propertyTypeClass);
		EOProperty eoProperty = new EOProperty(property, propertyType, this);
		eoProperty.init(dataAccessService, shape);
		properties.put(eoProperty.getName(), eoProperty);

		return eoProperty;
	}

	public void setProperty(EODAS dataAccessService, Shape shape) {
		if(properties == null) {
			// populate the properties for this type
			properties = new HashMap<String, Property>();

			// Simple attributes
			for(EOAttribute attribute: eoEntity.attributes()) {

				Class<?> propertyTypeClass = null;
				try {
					propertyTypeClass = Class.forName(attribute.className());
				} catch (ClassNotFoundException e) {
					if(primitiveMap.containsKey(attribute.className())) {
						propertyTypeClass = primitiveMap.get(attribute.className());
					} else {
						continue;
					}
				}
				if(propertyTypeClass == null) {
					continue;
				}

				addProperty(dataAccessService, propertyTypeClass, attribute, shape);

				if(eoEntity.primaryKeyAttributeNames().size() == 1) {
					String idName = eoEntity.primaryKeyAttributeNames().get(0);
					if (idName != null) {
						logger.debug("Identifier attribute name: " + idName);
						identifierProperty = (EOProperty)properties.get(idName);
					}
				}

				// Optimistic locking is based on snapshots and not
				// on a version column, so versionProperty field is not
				// initialized
			}

			// Relationships
			for(EORelationship relationship: eoEntity.relationships()) {

				Class<?> propertyTypeClass = null;
				try {
					propertyTypeClass = Class.forName(relationship.destinationEntity().className());
				}
				catch (ClassNotFoundException e) {
					continue;
				}

				if(propertyTypeClass == null) {
					continue;
				}

				EOProperty eoProperty = addProperty(dataAccessService, propertyTypeClass, relationship, shape);

				if(relationship.isToMany()) {
					eoProperty.setType(dataAccessService.getType(List.class));
				}
			}
		}
	}

	public void setOpposite(EODAS dataAccessService) {
		for(Property property: properties.values()) {
			((EOProperty)property).initMappedBy(dataAccessService);
		}
	}

	@Override
	public boolean isOpen() {
		// is this type backed by a concrete Java class, if not it is an open type
		try {
			Class.forName(eoEntity.className());
		} catch (ClassNotFoundException e) {
			return true;
		}

		return false;
	}

	@Override
	public boolean isSequenced() {
		return false;
	}

	@Override
	public boolean isAbstract() {
		return false;
	}

	@Override
	public List<Type> getBaseTypes() {
		return baseTypes;
	}

	public void setBaseType(List<Type> types) {
		baseTypes = types;
	}

	@Override
	public List<Property> getDeclaredProperties() {
		return new ArrayList(this.properties.values());
	}

	@Override
	public List<?> getAliasNames() {
		return new ArrayList<String>();
	}

	@Override
	public List<?> getInstanceProperties() {
		return new ArrayList<Object>();
	}

	@Override
	public Object get(Property property) {
		return null;
	}

	@Override public AccessType getAccessType ()
	{
		// EO supports only PROPERTY access as it manager fields using an array
		// and this can change
		return AccessType.PROPERTY;
	}

	@Override
	public Property getIdentifierProperty() {
		return identifierProperty;
	}

	@Override
	public boolean isEmbedded() {
		return false;
	}
	
	@Override
	public boolean isEntity() {
		return eoEntity.hasRealAttributes() && !eoEntity.isAbstractEntity();
	}		

	@Override
	public Property getVersionProperty() {
		return versionProperty;
	}

	@Override
	public boolean supportsDynamicUpdate() {
		return true;
	}
/*
	@Override
	public void initRootEntityType (DataAccessService das, Shape shape)
	{
		Class<?> rootEntityClass = getInstanceClass();

		Class<?> parentClass = rootEntityClass.getSuperclass();
		while (parentClass != null) {
			if (EOEnterpriseObject.class.isAssignableFrom(parentClass)) {
				if(shape.getType(parentClass) instanceof EntityType) {
					rootEntityClass = parentClass;
				}
			}
			parentClass = parentClass.getSuperclass();
		}

		rootEntityType = (EntityType) shape.getType(rootEntityClass);
	}
*/
}

