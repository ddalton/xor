package tools.xor.providers.eo;

import com.webobjects.eoaccess.EOEntity;
import com.webobjects.eoaccess.EORelationship;
import com.webobjects.eoaccess.EOSQLExpression;
import com.webobjects.eoaccess.EOSQLQualifier;
import com.webobjects.eocontrol.EOQualifier;
import com.webobjects.foundation.NSTimestamp;
import com.webobjects.foundation.NSTimestampFormatter;

import java.text.SimpleDateFormat;
import java.util.Date;

public class InQualifier extends EOSQLQualifier
{
    private static final String DATE_FORMAT = "'MM-DD-YYYY HH24:MI:SS'";

    private String key;
    private Object[] objects;
    public InQualifier (EOEntity eoEntity, String s, Object[] objects)
    {
        // EOF epects expression in the second arg, so just append =nil
        super(eoEntity, s+"=nil", objects);
        this.key = s;
        this.objects = objects;
    }

    /**
     * handle inmeomory qualification for in qualifier
     * @param value
     * @return
     */
    public boolean evaluateWithObject (Object value) {

        if (value == null) {
            return false;
        }

        for (int i=0; i<objects.length; i++) {
            if (value.equals(objects[i])) {
                return true;
            }
        }
        return false;
    }

    static public String alias (String key, EOSQLExpression eosqlExpression)
    {
        int index = key.lastIndexOf('.');
        String prefix = null;

        EOEntity last = eosqlExpression.entity();
        StringBuilder stringBuffer = new StringBuilder();

        if (index > 0) {
            String relpath = key.substring(0, index);
            prefix = eosqlExpression._aliasForRelationshipPath(relpath);
            EORelationship rel = eosqlExpression._rootEntityForExpression()._relationshipForPath(relpath);
            if (rel == null) {
                throw new RuntimeException(String.format(
                    "Can not find relationship %s at entity %s",
                    relpath,
                    eosqlExpression._rootEntityForExpression().name()));
            }
            last = rel.destinationEntity();
            stringBuffer.append(prefix + "." + last.attributeNamed(key.substring(index+1)).columnName());
        }
        else {
            // aliases are not used for deletes
            if (eosqlExpression.useAliases()) {
                prefix = eosqlExpression._aliasForRelationshipPath("");
                stringBuffer.append(prefix + "." + last.attributeNamed(key).columnName());
            }
            else {
                stringBuffer.append(last.attributeNamed(key).columnName());
            }
        }

        return stringBuffer.toString();

    }


    public String sqlStringForSQLExpression (EOSQLExpression eosqlExpression)
    {
        String alias = alias(key, eosqlExpression);
        StringBuilder stringBuffer = new StringBuilder(alias);

        stringBuffer.append(" in (");
        for (int i = 0; i < objects.length; i++)
        {
            Object o = objects[i];
            if (o instanceof String)
            {
                stringBuffer.append("'" + o + "',");
            }
            else if (o instanceof NSTimestamp)
            {
                NSTimestampFormatter formatter = new NSTimestampFormatter("%m-%d-%Y %H:%M:%S");
                stringBuffer.append("to_date('");
                stringBuffer.append(formatter.format((NSTimestamp) o));
                stringBuffer.append("', ");
                stringBuffer.append(DATE_FORMAT);
                stringBuffer.append("),");
            }
            else if (o instanceof Date)
            {
                SimpleDateFormat formatter
                     = new SimpleDateFormat ("MM-dd-yyyy HH:mm:ss");
                stringBuffer.append("to_date('");
                stringBuffer.append(formatter.format((Date) o));
                stringBuffer.append("', ");
                stringBuffer.append(DATE_FORMAT);
                stringBuffer.append("),");
            }
            else
            {
                stringBuffer.append(o);
                stringBuffer.append(",");
            }
        }
        stringBuffer.setCharAt(stringBuffer.length() - 1, ')');
        return stringBuffer.toString();
    }

    @Override
    public EOQualifier qualifierMigratedFromEntityRelationshipPath(EOEntity eoentity, String s)
    {
        String sKey = Support._translateKeyAcrossRelationshipPath(this.key,
                 s, eoentity);
        return new InQualifier(eoentity, sKey, objects);
    }
}
